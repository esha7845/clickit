<?php
session_start(); // Ensure session is started before destroying

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: login.php");
exit(); // Ensure script stops execution after redirection
?>
