<?php
session_start();

// Optionally destroy cart/session after order
// unset($_SESSION['cart']);
// session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You - Blinkit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', sans-serif;
        }
        .thank-you-box {
            max-width: 600px;
            margin: 80px auto;
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            text-align: center;
        }
        .thank-you-box h1 {
            color: #28a745;
            font-size: 2.5rem;
        }
        .order-summary {
            margin-top: 30px;
            background-color: #f1f3f5;
            padding: 20px;
            border-radius: 10px;
            text-align: left;
        }
        .btn-shop {
            background-color: #ffcb05;
            color: #000;
            font-weight: 600;
            border: none;
        }
        .btn-shop:hover {
            background-color: #ffc107;
        }
    </style>
</head>
<body>

<div class="thank-you-box">
    <img src="https://img.icons8.com/fluency/96/checked--v1.png" alt="Success" style="width: 80px;">
    <h1>Thank You!</h1>
    <p class="lead">Your order has been placed successfully.</p>


    <a href="index.php" class="btn btn-shop mt-4 px-4 py-2">Continue Shopping</a>
</div>

</body>
</html>
