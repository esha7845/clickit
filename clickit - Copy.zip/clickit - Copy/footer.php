
        <style>
             .download img {
            width: 254px;
        }

        /* .text {
            margin-bottom: 30px;
        } */
         .wrap{
            text-align: center;
            margin-top: 23px;
         }
         .hd1 h5{
            margin-right: 20px;
         }
         .remove-btn button{
            margin-left: 15px;
    background-color: white;
    color: black;
    border: none;
         } 
        </style>
</head>
<body>
<div class="head">
        <div class="row">
            <div class="col-md-5">
                <div class="hd1">
                <h5>Useful Links</h5>
                </div>
            </div>
            <div class="col-md-7">
                <div class="hd2">
                <h5>Categories <b style="color: green;">see all</b> </h5>
                </div>
            </div>
        </div>
    </div>





    <footer>
        <div class="row" style="margin-left: 20px;">
            <div class="col-md-5">
                <ul>
                    <!-- <h2>Useful Links</h2> -->
                    <li><a href="about.php">About</a></li>
                    <li><a href="career.php">Careers</a></li>
                    <li><a href="about.php">Blog</a></li>
                    <li><a href="about.php">Press</a></li>
                    <li><a href="about.php">Lead</a></li>
                    <li><a href="about.php">Value</a></li>
                </ul>

                <ul>
                    <li><a href="about.php">Privacy</a></li>
                    <li><a href="about.php">Terms</a></li>
                    <li><a href="about.php">FAQs</a></li>
                    <li><a href="about.php">Security</a></li>
                    <li><a href="mobile.php">Mobile</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>

                <ul>
                    <li><a href="about.php">Partner</a></li>
                    <li><a href="about.php">Franchise</a></li>
                    <li><a href="about.php">Seller</a></li>
                    <li><a href="about.php">Warehouse</a></li>
                    <li><a href="about.php">Deliver</a></li>
                    <li><a href="about.php">Resources</a></li>
                </ul>
            </div>
            <div class="col-md-7">
                <ul>
                    <!-- <div class="tx">
                            <h2>Categories </h2>
                            <h4 style="color: green;">see all</h4>
                        </div> -->
                    <li><a href="Productonline.php">Vegetables & Fruits</a></li>
                    <li><a href="Productonline.php">Cold Drinks & Juices</a></li>
                    <li><a href="Productonline.php">Backery & Biscuits</a></li>
                    <li><a href="Productonline.php">Dry Fruits, Masala & Oil</a></li>
                    <li><a href="Productonline.php">Paan Corner</a></li>
                    <li><a href="Productonline.php">Pharma & Wellness</a></li>
                    <li><a href="Productonline.php">Ice creams & Frozen Desserts</a></li>
                    <li><a href="Productonline.php">Beauty & Cosmetics</a></li>
                    <li><a href="Productonline.php">Magazines</a></li>

                </ul>

                <ul>
                    <li><a href="Productonline.php">Dairy & Breakfast</a></li>
                    <li><a href="Productonline.php">Instant & Frozen Food</a></li>
                    <li><a href="Productonline.php">Sweet Tooth</a></li>
                    <li><a href="Productonline.php">Sauces & Spreads</a></li>
                    <li><a href="Productonline.php">Organic & Premium</a></li>
                    <li><a href="Productonline.php">Cleaning Essential</a></li>
                    <li><a href="Productonline.php">Personal care</a></li>
                    <li><a href="Productonline.php">Books</a></li>
                    <li><a href="Productonline.php">Print Store</a></li>
                </ul>

                <ul>
                    <li><a href="Productonline.php">Munchies</a></li>
                    <li><a href="Productonline.php">Tea, Coffee & Health Drinks</a></li>
                    <li><a href="Productonline.php">Atta, Rice & Dal</a></li>
                    <li><a href="Productonline.php">Chicken, Meat & Fish</a></li>
                    <li><a href="Productonline.php">Baby care</a></li>
                    <li><a href="Productonline.php">Home & Office</a></li>
                    <li><a href="Productonline.php">Pet care</a></li>
                    <li><a href="Productonline.php">Toys & Games</a></li>
                    <li><a href="Productonline.php">Navaratri Specials</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <div class="download">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-3">
                <div class="wrap">
                    © Blink Commerce Private Limited, 2016-2024
                </div>
            </div>
            <div class="col-md-4">
                Download App
                <img src="https://global.discourse-cdn.com/turtlehead/original/2X/e/ee0e6fd4d6ad3283ce1b38e28481a51cb25a9dac.png"
                    class="img-fluid" alt="...">

            </div>
            <div class="col-md-4">
                <div class="facebook">
                    <i class="fa-brands fa-facebook-f"></i>
                </div>
                <div class="twitter">
                    <i class="fa-brands fa-twitter"></i>
                </div>
                <div class="instagram">
                    <i class="fa-brands fa-instagram"></i>
                </div>
                <div class="in">
                    <i class="fa-brands fa-linkedin-in"></i>
                </div>
                <div class="thread">
                    <i class="fa-brands fa-threads"></i>
                </div>
            </div>
        </div>
    </div>
    <br>
    <p style="text-align: center;">By continuing past this page you agree to our Terms, Cookie policy and Privacy
        policy. All trademarks <br> are properties of their respective owners. © Blink Commerce Private Limited
        2016-2024</p>

    

<div class="col-md-1" style="margin-top: 4px;">
   
<?php 


$session_id = session_id();
$cart_data1 = $db->query("SELECT * FROM `cart` WHERE session_id = '$session_id'");
$total_items = $cart_data1->num_rows;

$subtotal = 0;
?>

<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title"><i class="fa-solid fa-cart-shopping"></i> My Cart</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div> 
    <hr>

    <div class="offcanvas-body">
        <div class="time">
            <i class="fa-solid fa-stopwatch"></i>
            <div class="set">
                <h6>Delivery in 9 minutes</h6>
                <p>Shipment of <span id="total-items"><?= $total_items ?></span> items</p>
            </div>
        </div>

        <div id="cart-items">
            <?php 
            while($cart_values = $cart_data1->fetch_object()) {
                $p_id = $cart_values->product_id;
                $p_data = $db->query("SELECT * FROM product WHERE p_id = '$p_id'");
                $p_value = $p_data->fetch_object();

                $subtotal += ($cart_values->price * $cart_values->quantity);
            ?>
            <div class="img-tx" id="cart-item-<?= $p_id ?>">
                <img src="uploads/<?= $p_value->image ?>" alt="">
                <div class="te-xt">
                    <?= $p_value->p_name ?> <br>
                    <?= $p_value->unit ?> <br>
                    <i class="fa-solid fa-indian-rupee-sign"></i> <span class="price"><?= $cart_values->price ?></span>
                </div>
                <div class="remv"> 
                    <button type="button" class="set-get" onclick="updateQuantity(<?= $p_id ?>, 'decrease')">-</button>
                    <span id="quantity-<?= $p_id ?>"><?= $cart_values->quantity ?></span>
                    <button type="button" class="set-get" onclick="updateQuantity(<?= $p_id ?>, 'increase')">+</button>
                    
                    <button type="button" class="remove-btn" onclick="removeItem(<?= $p_id ?>, <?= $cart_values->price ?>)">Remove</button>
                </div>
            </div>
            <?php } ?>
        </div>

        <div class="details">
            <div class="text-1"><h5>Bill details</h5></div>
            <div class="text-2"><h6>Items total</h6> ₹<span id="items-total"><?= number_format($subtotal, 2) ?></span></div>
            <div class="text-2"><h6>Delivery charge</h6> ₹<span id="delivery-charge">25</span></div>
            <div class="text-2"><h6>Handling charge</h6> ₹<span id="handling-charge">5</span></div> 
            <div class="text-1"><h6>Grand total</h6><b>₹<span id="grand-total"><?= number_format($subtotal + 25 + 5, 2) ?></span></b></div>
        </div>

        <div class="btu-btn">
            <a href="payment.php"><button class="btn btn-primary">Proceed to Checkout</button></a>
        </div>
    </div>
</div>

    <script>
        function updateQuantity(productId, action) {
            let quantitySpan = document.getElementById("quantity-" + productId);
            let price = parseFloat(document.getElementById("cart-item-" + productId).querySelector(".price").innerText);
            let itemsTotalSpan = document.getElementById("items-total");
            let grandTotalSpan = document.getElementById("grand-total");

            let quantity = parseInt(quantitySpan.innerText);
            if (action === 'increase') {
                quantity += 1;
            } else if (action === 'decrease' && quantity > 1) {
                quantity -= 1;
            }
            quantitySpan.innerText = quantity;
            updateTotal();
        }

        function removeItem(productId, price) {
            if (confirm('Are you sure you want to remove this item?')) {
                document.getElementById("cart-item-" + productId).remove();
                updateTotal();

                fetch("admin/action/add_to_cart.php?submit=remove_from_cart&product_id=" + productId)
                .then(response => console.log("Item removed from database"));
            }
        }

        function updateTotal() {
            let itemsTotal = 0; 
            let totalItems = 0;
            document.querySelectorAll(".img-tx").forEach(function (item) {
                let itemPrice = parseFloat(item.querySelector(".price").innerText);
                let itemQuantity = parseInt(item.querySelector("span[id^='quantity-']").innerText);
                itemsTotal += itemPrice * itemQuantity;
                totalItems += itemQuantity;
            });

            document.getElementById("items-total").innerText = itemsTotal.toFixed(2);
            document.getElementById("grand-total").innerText = (itemsTotal + 25 + 5).toFixed(2);
            document.getElementById("total-items").innerText = totalItems;

            if (totalItems === 0) {
                document.querySelector(".btu-btn button").disabled = true;
            }
        }
    </script>




   
        
</body>
</html>