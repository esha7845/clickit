<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .dext3 {
            background-color: #03A9F4;
            margin-right: 15px;
            height: 50px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .dext3 b {
            margin-left: 20px;
        }

        .vw {
            margin-left: 20px;
            margin-top: 10px;
        }

        .st {
            text-align: left;
            margin-left: 10px;
            margin-top: 15px;
        }

        .btnn {
            text-align: left;
            margin-left: 20px;
            margin-bottom: 20px;

        }

        .btnn button {
            background-color: #01A185;
            color: white;
            width: 85px;
            height: 36px;
            border-radius: 2px;
            border: #01A185;
            margin-bottom: -9px;

        }

        .form-label label {
            margin-bottom: 6px;
        }

        .dext1 b {
            margin-left: 20px;
        }

        .dext3 b {
            margin-left: 20px;
        }

        td img {
            width: 287px;
            height: 185px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        table {
            border: "n";
            width: 1203px;
            border-collapse: collapse;
            text-align: left;
            margin-left: 10px;
            background-color: #F9F9F9;
            margin-top: 15px;
            color: grey;

        }

        table td {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        table th {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        td i {
            width: 150px;

        }

        .ic {
            display: flex;
            /* justify-content: space-around; */
            align-items: center;
            margin-left: 30px;
        }

        .ic i {
            background-color: red;
            color: white;
            border-radius: 3px;
            width: 41px;
            height: 33px;
            font-size: 12px;
            margin-right: 5px;
            /* margin-top: 10px; */
            /* display: flex;
            align-items: center; */
        }

        .dext4 {
            background-color: #FFFFFF;
            width: 1222px;
            height: 520px;
        }

        .dr-list {
            display: flex;
            justify-content: space-between;
        }

        .d-list1 {
            display: flex;
        }

        .d-list2 {
            display: flex;
        }

        .dropdown-menu {
            width: 40px;
        }

        #num {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 93px;
            text-align: left;
            margin-top: 20px;
        }

        .dr-list p {
            margin-left: 20px;
            margin-top: 26px;
        }

        #formGroupExampleInput {
            width: 360px;
            height: 41px;
            border-radius: 3px;
            margin-top: 0px;
            margin-right: 10px;
        }

        .dext5 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 15px;
        }

        .pagin {
            margin-right: 15px;
        }

        #exampleFormControlInput1 {
            width: 182px;
            height: 43px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }

        #formFileMultiple {
            width: 360px;
            height: 40px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }

        #num-1 {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 132px;
            text-align: left;
            /* margin-top: 10px; */
            margin-right: 20px;
            margin-bottom: 10px;
        }
        .card-header{
            background-color: #03A9F4;
        }
    </style>
</head>

<body style="overflow-x: hidden;">

    <div class="row g-0 text-center">
        <div class="col-sm-6 col-md-2">
        <?php include 'sidebar.php';?>
        </div>
        <div class="col-6 col-md-10">
            <div class="menu">
                <div class="row">
                <?php include 'header.php';?>
                    <div class="row">
                        <div class="nav2">
                            <div class="col-md-1">
                                <b>Dashboard</b>
                            </div>
                            <div class="col-md-10"></div>
                            <div class="col-md-1">
                                <p>Dashboard</p>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="container text-center">
                            <div class="row g-4">
                                <div class="col-3">
                                    <div class="p-3">
                                        <div class="box1">
                                            <div class="head1">
                                                <b>Total Order</b>
                                            </div>
                                            <div class="head2">
                                                <h3><b>14</b></h3>
                                                <!-- <br> -->
                                                <a href="">View Order</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="p-3">
                                        <div class="box1">
                                            <div class="head3">
                                                <b>Today Order</b>
                                            </div>
                                            <div class="head4">
                                                <h3><b>0</b></h3>
                                                <!-- <br> -->
                                                <a href="">View Order</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="p-3">
                                        <div class="box1">
                                            <div class="head5">
                                                <b>Cancel Order</b>
                                            </div>
                                            <div class="head6">
                                                <h3><b>0</b></h3>
                                                <!-- <br> -->
                                                <a href="">View Order</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="p-3">
                                        <div class="box1">
                                            <div class="head7">
                                                <b>Earning</b>
                                            </div>
                                            <div class="head8">

                                                <h3><b>Rs 15,957.00</b></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="vw">
                            <div class="col-md-12">
                                <div class="dext3">
                                    <b>View Testimonial</b>
                                </div>
                                <div class="dext4">
                                    <div class="dr-list">
                                        <div class="d-list1">
                                            <p>Show</p>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" id="num" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    10
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="#">10</a></li>
                                                    <li><a class="dropdown-item" href="#">35</a></li>
                                                    <li><a class="dropdown-item" href="#">50</a></li>
                                                    <li><a class="dropdown-item" href="#">100</a></li>
                                                </ul>
                                            </div>
                                            <p>entries</p>
                                        </div>
                                        <div class="d-list2">
                                            <p>Search:</p>
                                            <div class="input-group">
                                                <input type="search" class="form-control" id="exampleFormControlInput1"
                                                    placeholder="search">
                                            </div>
                                        </div>
                                    </div>
                                    <table>
                                        <tr>
                                            <th>Sl No</th>
                                            <th>View Details & Print</th>
                                            <th>User Details</th>
                                            <th>Other Details</th>
                                            <th>Address</th>
                                            <th>Order lds</th>
                                            <th>Total Bill</th>
                                            <th>Order Status</th>
                                            <th>Deliver Date and Time</th>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><i class="fa-solid fa-print" style="  background-color: #01A185;
                                                color: white;
                                                border-radius: 3px;
                                                width: 41px;
                                                height: 33px;
                                                padding: 7px 13px;
                                                text-align: center; margin-left: 42px;"></i></td>
                                            <td>
                                                Altab <br>
                                                altabraja4@gmail.com
                                                8786474659
                                            </td>

                                            <td>
                                                A <br>
                                                altabraja4@gmail.com
                                                3456787654
                                            </td>
                                            <td>
                                                home
                                                bhubaneswar,8789
                                            </td>
                                            <td>order26904</td>
                                            <td>Rs 650.00</td>
                                            <td>2020-12-05 08:20</td>
                                            <td>
                                                <p
                                                    style="width: 136px; height: 28px; background-color: #03A9F4; text-align: center; color: white; margin-left: 10px; margin-top: 10px;">
                                                    Placed</p>
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" id="num-1"
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        Placed
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="#">Packed</a></li>
                                                        <li><a class="dropdown-item" href="#">On the way</a></li>
                                                        <li><a class="dropdown-item" href="#">Delivered</a></li>
                                                        <li><a class="dropdown-item" href="#">Order Cancel</a></li>
                                                    </ul>
                                                    <div class="btnn">
                                                        <button>Update</button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>2</td>
                                            <td><i class="fa-solid fa-print" style="  background-color: #01A185;
                                                color: white;
                                                border-radius: 3px;
                                                width: 41px;
                                                height: 33px;
                                                padding: 7px 13px;
                                                text-align: center; margin-left: 42px;"></i></td>
                                            <td>
                                                esha <br>
                                                esga34@gmail.com
                                                8786474659
                                            </td>

                                            <td>
                                                A <br>
                                                padmabati@gmail.com
                                                8756498757
                                            </td>
                                            <td>
                                                home
                                                bhubaneswar,76879
                                            </td>
                                            <td>order26904</td>
                                            <td>Rs 650.00</td>
                                            <td>2020-12-05 08:20</td>
                                            <td>
                                                <p
                                                    style="width: 136px; height: 28px; background-color: #03A9F4; text-align: center; color: white; margin-left: 10px; margin-top: 10px;">
                                                    Placed</p>
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" id="num-1"
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        Placed
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="#">Packed</a></li>
                                                        <li><a class="dropdown-item" href="#">On the way</a></li>
                                                        <li><a class="dropdown-item" href="#">Delivered</a></li>
                                                        <li><a class="dropdown-item" href="#">Order Cancel</a></li>
                                                    </ul>
                                                    <div class="btnn">
                                                        <button>Update</button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                    </table>
                                    <div class="dext5">
                                        <p style="margin-left: 20px;">Showing 1 to 3 of 3 entries</p>
                                        <div class="pagin">
                                            <nav aria-label="...">
                                                <ul class="pagination">
                                                    <li class="page-item disabled">
                                                        <span class="page-link">Previous</span>
                                                    </li>
                                                    <li class="page-item active" aria-current="page">
                                                        <span class="page-link">1</span>
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">Next</a>
                                                    </li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <div class="row" style="margin-top: 358px">
                    <?php include 'footer.php';?>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top: 100px; height: 560px;">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Edit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="margin-left: 6px;">
                    <div class="card-header">
                        <b>Add Video</b>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="videoName" style="margin-right: 370px;" class="form-label">Name</label>
                            <input type="text" class="form-control" style="width: 420px;" id="videoName"
                                placeholder="Enter video name">
                        </div>
                        <div class="mb-3">
                            <label for="videoCode" style="margin-right: 335px;" class="form-label">Video Code</label>
                            <input type="text" class="form-control" style="width: 420px;" id="videoCode"
                                placeholder="Enter video code">
                        </div>
                        <div class="mb-3">
                            <div class="st">
                                <label for="formFileMultiple" class="form-label">Upload Image <b
                                        style="color: red;">1000 *700</b>
                                </label>
                                <input class="form-control" type="file" id="formFileMultiple" multiple>
                            </div>

                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Understood</button>
            </div> -->
            <button class="btnn btn-primary" style="background-color: black;     border-radius: 3px;
                        background-color: black;
                        color: white;
                        width: 98px;
                        height: 37px;
                        text-align: center;
                        margin-left: 200px;
                        margin-bottom: 75px;
                        ">Submit</button>
        </div>
    </div>
</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>