<div class="footer">
    <div class="col-md-5">
        <p>020 - 2020 © Ifotechsys.</p>
    </div>
    <div class="col-md-7"></div>
</div>