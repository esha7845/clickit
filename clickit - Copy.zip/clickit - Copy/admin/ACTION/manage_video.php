<?php
include '../config.php';
$submit = $_REQUEST['submit'];
$create_at = date('y-m-d h:i:s');
$update_at = date('y-m-d h:i:s');

switch ($submit) {
    case 'submit_form':
        $v_code = mysqli_real_escape_string($db, $_REQUEST['v_code']);
       
        

        // Insert base data into the table
        $db->query("INSERT INTO `video`(`v_id`, `v_code`, `create_at`) 
                                    VALUES (NULL, '$v_code', '$create_at')");
        $v_id = $db->insert_id;

        // // Image upload logic
        // if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
        //     $file = $_FILES['file']['name'];
        //     $ext = pathinfo($file, PATHINFO_EXTENSION);
        //     $allowedTypes = ["jpg", "jpeg", "png", "gif","webp","JPG"];

        //     if (in_array(strtolower($ext), $allowedTypes)) {
        //         $rand = rand(10000, 99999);
        //         $filename = 'file' . $rand . '.' . $ext;
        //         $filepath = "../../uploads/" . $filename;

        //         if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
        //             // Update the table with the file name
        //             $db->query("UPDATE `category` SET `file` = '$filename' WHERE c_id = '$c_id'");
        //         } else {
        //             echo '<div class="alert alert-danger">Failed to upload the image. Please try again.</div>';
        //         }
        //     } else {
        //         echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
        //         die();
        //     }
        // }

        header("Location: ../video.php");
         break;

  case 'delete':
    if (!isset($_REQUEST['v_id']) || empty($_REQUEST['v_id'])) {
        die('Invalid request: video ID is missing.');
    }

    $v_id = mysqli_real_escape_string($db, $_REQUEST['v_id']);

    // // Fetch the image before deleting
    // $result = $db->query("SELECT file FROM `location` WHERE l_id = '$l_id'");
    // $row = $result->fetch_assoc();
    // if ($row) {
    //     $imagePath = "../uploads/" . $row['image'];
    //     if (file_exists($imagePath)) {
    //         unlink($imagePath); // Delete the image file
    //     }
    // }

    // Delete the banner from the database
    $delete = $db->query("DELETE FROM `video` WHERE v_id ='$v_id'");

    if ($delete) {
        header("Location: ../video.php?success=video Deleted Successfully");
        exit();
    } else {
        echo "Error deleting video.";
    }
    break;


    case 'update_form':
        $v_id = mysqli_real_escape_string($db, $_POST['v_id']);
        $v_name = mysqli_real_escape_string($db, $_POST['v_name']);
    
        // Update base data (removed the extra comma)
        $db->query("UPDATE `video` SET `v_name` = '$v_name' WHERE `v_id` = '$v_id'");
    
        // Handle Image upload
        if (!empty($_FILES['file']['name'])) {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];
    
            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;
    
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Remove the old image
                    $result = $db->query("SELECT file FROM `video` WHERE v_id = '$v_id'");
                    $row = $result->fetch_assoc();
    
                    if ($row && file_exists("../../uploads/" . $row['file'])) {
                        unlink("../../uploads/" . $row['file']);
                    }
    
                    // Update new image
                    $db->query("UPDATE `video` SET `file` = '$filename' WHERE `v_id` = '$v_id'");
                }
            }
        }
        header("Location: ../video.php");
        break;

    

    default:
        echo "No action found";
        break;
}

?>

