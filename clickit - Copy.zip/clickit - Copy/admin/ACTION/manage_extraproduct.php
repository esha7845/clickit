<?php
include '../config.php';

$submit = $_REQUEST['submit'] ?? '';
$create_at = date('Y-m-d H:i:s');
$update_at = date('Y-m-d H:i:s');

switch ($submit) {
    case 'submit_form': 
        $p_id = mysqli_real_escape_string($db, $_POST['p_id']);
        $ep_name = 'Extra Product'; // Default name, you can modify this

        // File upload logic
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'extraproduct_' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Insert into database
                    $query = "INSERT INTO `extraproduct` (`p_id`, `ep_name`, `file`, `create_at`, `update_at`) 
                              VALUES ('$p_id', '$ep_name', '$filename', '$create_at', '$update_at')";
                    
                    if ($db->query($query)) {
                        header("Location: ../extraproduct.php?success=Product Added");
                        exit();
                    } else {
                        echo '<div class="alert alert-danger">Database error: ' . $db->error . '</div>';
                    }
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the file. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF, WEBP.</div>';
                die();
            }
        } else {
            echo '<div class="alert alert-danger">Please select a file to upload.</div>';
        }
        break;
    case 'delete': // DELETE SUBCATEGORY
        if (!isset($_REQUEST['ep_id']) || empty($_REQUEST['ep_id'])) {
            die('Invalid request: Subcategory ID is missing.');
        }

        $ep_id = mysqli_real_escape_string($db, $_REQUEST['ep_id']);

        // Fetch and delete file file
        $result = $db->query("SELECT file FROM `extraproduct` WHERE ep_id = '$ep_id'");
        $row = $result->fetch_assoc();
        if ($row && file_exists("../../uploads/" . $row['file'])) {
            unlink("../../uploads/" . $row['file']);
        }

        // Delete from the database
        $delete = $db->query("DELETE FROM `extraproduct` WHERE ep_id ='$ep_id'");

        if ($delete) {
            header("Location: ../extraproduct.php?success=Subcategory Deleted Successfully");
            exit();
        } else {
            echo "Error deleting subcategory.";
        }
        break;

        case 'update_form': // UPDATE SUBCATEGORY
            $ep_id = mysqli_real_escape_string($db, $_POST['ep_id']);
            $p_id = mysqli_real_escape_string($db, $_POST['p_id']);
            $ep_name = mysqli_real_escape_string($db, $_POST['ep_name']);
    
            // Update base data
            $db->query("UPDATE `extraproduct` SET `p_id` = '$p_id', `ep_name` = '$ep_name', WHERE `ep_id` = '$ep_id'");
    
            // Fetch existing file before uploading a new one
            $result = $db->query("SELECT file FROM `extraproduct` WHERE ep_id = '$ep_id'");
            $row = $result->fetch_assoc();
            $oldFile = $row ? $row['file'] : null;
    
            // Handle file upload
             if (!empty($_FILES['file']['name'])) {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];
    
            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;
    
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Remove the old image
                    $result = $db->query("SELECT file FROM `extraproduct` WHERE ep_id = '$ep_id'");
                    $row = $result->fetch_assoc();
    
                    if ($row && file_exists("../../uploads/" . $row['file'])) {
                        unlink("../../uploads/" . $row['file']);
                    }
    
                    // Update new image
                    $db->query("UPDATE `extraproduct` SET `file` = '$filename' WHERE `ep_id` = '$ep_id'");
                }
            }
        }
    
            header("Location: ../extraproduct.php");
            break;
    

    default:
        echo "No action found";
        break;
}
?>
