<?php
include '../config.php';

$submit = $_REQUEST['submit'];
$create_at = date('Y-m-d H:i:s');
$update_at = date('Y-m-d H:i:s');

switch ($submit) {
    case 'submit_form': // ADD SUBCATEGORY
        $c_id = mysqli_real_escape_string($db, $_REQUEST['c_id']);
        $sub_name = mysqli_real_escape_string($db, $_REQUEST['sub_name']);
        $description = mysqli_real_escape_string($db, $_REQUEST['description']);

        // Insert base data into the table
        $db->query("INSERT INTO `subcategory`(`s_id`, `c_id`, `sub_name`, `description`, `create_at`) 
                    VALUES (NULL, '$c_id', '$sub_name', '$description', '$create_at')");
        $s_id = $db->insert_id;

        // file upload logic
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'subcategory_' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Update the table with the file name
                    $db->query("UPDATE `subcategory` SET `file` = '$filename' WHERE s_id = '$s_id'");
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the file. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
                die();
            }
        }

        header("Location: ../subcategory.php");
        break;

    case 'delete': // DELETE SUBCATEGORY
        if (!isset($_REQUEST['s_id']) || empty($_REQUEST['s_id'])) {
            die('Invalid request: Subcategory ID is missing.');
        }

        $s_id = mysqli_real_escape_string($db, $_REQUEST['s_id']);

        // Fetch and delete file file
        $result = $db->query("SELECT file FROM `subcategory` WHERE s_id = '$s_id'");
        $row = $result->fetch_assoc();
        if ($row && file_exists("../../uploads/" . $row['file'])) {
            unlink("../../uploads/" . $row['file']);
        }

        // Delete from the database
        $delete = $db->query("DELETE FROM `subcategory` WHERE s_id ='$s_id'");

        if ($delete) {
            header("Location: ../subcategory.php?success=Subcategory Deleted Successfully");
            exit();
        } else {
            echo "Error deleting subcategory.";
        }
        break;

        case 'update_form': // UPDATE SUBCATEGORY
            $s_id = mysqli_real_escape_string($db, $_POST['s_id']);
            $c_id = mysqli_real_escape_string($db, $_POST['c_id']);
            $sub_name = mysqli_real_escape_string($db, $_POST['sub_name']);
            $description = mysqli_real_escape_string($db, $_POST['description']);
    
            // Update base data
            $db->query("UPDATE `subcategory` SET `c_id` = '$c_id', `sub_name` = '$sub_name', `description` = '$description' WHERE `s_id` = '$s_id'");
    
            // Fetch existing file before uploading a new one
            $result = $db->query("SELECT file FROM `subcategory` WHERE s_id = '$s_id'");
            $row = $result->fetch_assoc();
            $oldFile = $row ? $row['file'] : null;
    
            // Handle file upload
             if (!empty($_FILES['file']['name'])) {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];
    
            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;
    
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Remove the old image
                    $result = $db->query("SELECT file FROM `subcategory` WHERE s_id = '$s_id'");
                    $row = $result->fetch_assoc();
    
                    if ($row && file_exists("../../uploads/" . $row['file'])) {
                        unlink("../../uploads/" . $row['file']);
                    }
    
                    // Update new image
                    $db->query("UPDATE `subcategory` SET `file` = '$filename' WHERE `s_id` = '$s_id'");
                }
            }
        }
    
            header("Location: ../subcategory.php");
            break;
    

    default:
        echo "No action found";
        break;
}
?>
