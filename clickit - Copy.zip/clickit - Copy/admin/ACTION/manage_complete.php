<?php
include '../config.php'; // Make sure this file contains $db = new mysqli(...)

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {

        case 'update_status':
            if (isset($_POST['order_id'], $_POST['sts'])) {
                $order_id = trim($_POST['order_id']);
                $sts = strtolower(trim($_POST['sts']));

                // Allowed statuses (must match your dropdown values)
                $allowed_statuses = ['ordered', 'processing', 'shipped', 'delivered', 'cancelled'];

                if (!in_array($sts, $allowed_statuses)) {
                    die("❌ Invalid status.");
                }

                // Update status in the database
                $stmt = $db->prepare("UPDATE orders SET sts = ?, update_at = NOW() WHERE order_id = ?");
                $stmt->bind_param("ss", $sts, $order_id);

                if ($stmt->execute()) {
                    // ✅ Success - redirect back to complete.php
                    header("Location: ../complete.php?status_updated=1");
                    exit;
                } else {
                    echo "❌ Failed to update order status. Please try again.";
                }

                $stmt->close();
            } else {
                echo "❌ Order ID or status not provided.";
            }
            break;

        // 🔧 Future actions like delete_order, assign_delivery etc. can go here
        // case 'delete_order':
        //     // your logic
        //     break;

        default:
            echo "❌ Invalid action requested.";
            break;
    }
} else {
    echo "❌ Invalid request method or missing action.";
}
?>
