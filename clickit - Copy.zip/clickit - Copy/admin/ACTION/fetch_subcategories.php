<?php
include '../config.php';

if (isset($_POST['c_id'])) {
    $c_id = mysqli_real_escape_string($db, $_POST['c_id']);
    $subcategories = $db->query("SELECT * FROM `subcategory` WHERE `c_id` = '$c_id'");

    echo '<option value="">Select Sub-Category</option>';
    while ($sub = $subcategories->fetch_object()) {
        echo '<option value="' . $sub->s_id . '">' . htmlspecialchars($sub->sub_name) . '</option>';
    }
}
?>
