<?php
session_start();
include "../config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $a_email = mysqli_real_escape_string($db, $_POST["a_email"]);
    $a_password = $_POST["a_password"];

    $query = "SELECT * FROM `admin` WHERE `a_email` = '$a_email'";
    $result = mysqli_query($db, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        
        if (password_verify($a_password, $row["a_password"])) {
            $_SESSION["admin_id"] = $row["id"];
            $_SESSION["admin_name"] = $row["a_name"];
            header("Location: ../dashboard1.php");
            exit;
        } else {
            $_SESSION["error"] = "Invalid email or password!";
            header("Location: ../login.php");
            exit;
        }
    } else {
        $_SESSION["error"] = "No account found with this email!";
        header("Location: ../login.php");
        exit;
    }
}
?>