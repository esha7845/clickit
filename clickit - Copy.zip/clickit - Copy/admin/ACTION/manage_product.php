<?php
include '../config.php';

$submit = $_REQUEST['submit'];
$create_at = date('Y-m-d H:i:s');
$update_at = date('Y-m-d H:i:s');

switch ($submit) {
    case 'submit_form': // ADD PRODUCT
        $c_id = mysqli_real_escape_string($db, $_REQUEST['c_id']);
        $s_id = mysqli_real_escape_string($db, $_REQUEST['s_id']);
        $p_name = mysqli_real_escape_string($db, $_REQUEST['p_name']);
        $price = mysqli_real_escape_string($db, $_REQUEST['price']);
        $m_price = mysqli_real_escape_string($db, $_REQUEST['m_price']);
        $unit = mysqli_real_escape_string($db, $_REQUEST['unit']);
        $stock = mysqli_real_escape_string($db, $_REQUEST['stock']);
        $description = mysqli_real_escape_string($db, $_REQUEST['description']);
        

        // Insert base data into the table
        $db->query("INSERT INTO `product`(`p_id`, `s_id`, `c_id`, `p_name`, `price`,`m_price`,`unit`,`stock`,`description`, `create_at`, `update_at`) 
                    VALUES (NULL, '$s_id', '$c_id', '$p_name', '$price','$m_price','$unit','$stock', '$description', '$create_at', '$update_at')");
        $p_id = $db->insert_id;

        // File upload logic
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'product_' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    $db->query("UPDATE `product` SET `image` = '$filename' WHERE p_id = '$p_id'");
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the file. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
                die();
            }
        }

        header("Location: ../product.php");
        break;

    case 'delete': // DELETE PRODUCT
        if (!isset($_REQUEST['p_id']) || empty($_REQUEST['p_id'])) {
            die('Invalid request: Product ID is missing.');
        }

        $p_id = mysqli_real_escape_string($db, $_REQUEST['p_id']);

        // Fetch and delete file
        $result = $db->query("SELECT image FROM `product` WHERE p_id = '$p_id'");
        $row = $result->fetch_assoc();
        if ($row && file_exists("../../uploads/" . $row['image'])) {
            unlink("../../uploads/" . $row['image']);
        }

        // Delete from the database
        $delete = $db->query("DELETE FROM `product` WHERE p_id ='$p_id'");

        if ($delete) {
            header("Location: ../product.php?success=Product Deleted Successfully");
            exit();
        } else {
            echo "Error deleting product.";
        }
        break;

    case 'update_form': // UPDATE PRODUCT
        $p_id = mysqli_real_escape_string($db, $_POST['p_id']);
        $c_id = mysqli_real_escape_string($db, $_POST['c_id']);
        $s_id = mysqli_real_escape_string($db, $_POST['s_id']);
        $p_name = mysqli_real_escape_string($db, $_POST['p_name']);
        $price = mysqli_real_escape_string($db, $_POST['price']);
        $m_price = mysqli_real_escape_string($db, $_POST['m_price']);
        $unit = mysqli_real_escape_string($db, $_POST['unit']);
        $stock = mysqli_real_escape_string($db, $_REQUEST['stock']);
        $description = mysqli_real_escape_string($db, $_REQUEST['description']);
        

        // Update base data
        $db->query("UPDATE `product` SET `c_id` = '$c_id', `s_id` = '$s_id', `p_name` = '$p_name', `price` = '$price', `m_price` = '$m_price', `unit` = '$unit', `stock` = '$stock', `description` = '$description',   `update_at` = '$update_at' WHERE `p_id` = '$p_id'");

        // Fetch existing file before uploading a new one
        $result = $db->query("SELECT image FROM `product` WHERE p_id = '$p_id'");
        $row = $result->fetch_assoc();
        $oldFile = $row ? $row['image'] : null;

        // Handle file upload
        if (!empty($_FILES['file']['name'])) {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'product_' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Remove the old image
                    if ($oldFile && file_exists("../../uploads/" . $oldFile)) {
                        unlink("../../uploads/" . $oldFile);
                    }
                    
                    // Update new image
                    $db->query("UPDATE `product` SET `image` = '$filename' WHERE `p_id` = '$p_id'");
                }
            }
        }

        header("Location: ../product.php");
        break;

    default:
        echo "No action found";
        break;
}
?>
