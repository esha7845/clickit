<?php
include '../config.php';
$submit = $_REQUEST['submit'];
$create_at = date('y-m-d h:i:s');
$update_at = date('y-m-d h:i:s');

switch ($submit) {
    case 'submit_form':
        $t_name = mysqli_real_escape_string($db, $_REQUEST['t_name']);
        // echo"$t_name";
        

        // Insert base data into the table
        $db->query("INSERT INTO `testimonia`(`t_id`, `t_name`, `create_at`) 
                    VALUES (NULL, '$t_name', '$create_at')");
        $t_id = $db->insert_id;

        // Image upload logic
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif","webp","JPG"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Update the table with the file name
                    $db->query("UPDATE `testimonia` SET `file` = '$filename' WHERE t_id = '$t_id'");
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the image. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
                die();
            }
        }

        header("Location: ../testimonial.php");
        break;

  case 'delete':
    if (!isset($_REQUEST['t_id']) || empty($_REQUEST['t_id'])) {
        die('Invalid request: testimonial ID is missing.');
    }

    $t_id = mysqli_real_escape_string($db, $_REQUEST['t_id']);

    // Fetch the image before deleting
    $result = $db->query("SELECT file FROM `testimonia` WHERE t_id = '$t_id'");
    $row = $result->fetch_assoc();
    if ($row) {
        $imagePath = "../uploads/" . $row['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath); // Delete the image file
        }
    }

    // Delete the banner from the database
    $delete = $db->query("DELETE FROM `testimonia` WHERE t_id ='$t_id'");

    if ($delete) {
        header("Location: ../testimonial.php?success=testimonia Deleted Successfully");
        exit();
    } else {
        echo "Error deleting mobile.";
    }
    break;


    case 'update_form':
        $t_id = mysqli_real_escape_string($db, $_POST['t_id']);
        $t_name = mysqli_real_escape_string($db, $_POST['t_name']);
    
        // Update base data (removed the extra comma)
        $db->query("UPDATE `testimonia` SET `t_name` = '$t_name' WHERE `t_id` = '$t_id'");
    
        // Handle Image upload
        if (!empty($_FILES['file']['name'])) {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];
    
            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "../../uploads/" . $filename;
    
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Remove the old image
                    $result = $db->query("SELECT file FROM `testimonia` WHERE t_id = '$t_id'");
                    $row = $result->fetch_assoc();
    
                    if ($row && file_exists("../../uploads/" . $row['file'])) {
                        unlink("../../uploads/" . $row['file']);
                    }
    
                    // Update new image
                    $db->query("UPDATE `testimonia` SET `file` = '$filename' WHERE `t_id` = '$t_id'");
                }
            }
        }
        header("Location: ../testimonial.php");
        break;

    

    default:
        echo "No action found";
        break;
}
?>

