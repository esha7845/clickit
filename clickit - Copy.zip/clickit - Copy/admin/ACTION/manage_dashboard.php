<form action="ACTION/manage_banner.php" method="POST" enctype="multipart/form-data">
                                    <div class="dext2">
                                        <div class="mb-3">
                                            <div class="st">
                                                <label for="formGroupExampleInput" class="form-label">Title</label>
                                                <input type="text" class="form-control" id="formGroupExampleInput"
                                                    placeholder="Title">
                                            </div>

                                        </div>
                                        <div class="mb-3">
                                            <div class="st">
                                                <label for="formFileMultiple" class="form-label">Upload Image <b
                                                        style="color: red;">1000 *1000</b>
                                                </label>
                                                <input class="form-control" type="file" id="formFileMultiple" multiple>
                                            </div>

                                        </div>
                                        <h6 style="text-align: left; margin-left: 14px;">Description</h6>
                                        <div class="form-floating">
                                            <textarea class="form-control" placeholder="Leave a comment here"
                                                id="floatingTextarea2" style="height: 110px"></textarea>
                                            <label for="floatingTextarea2"
                                                style="margin-left: 14px;">Description</label>
                                        </div>
                                        <div class="btnn">
                                            <button>Submit</button>
                                        </div>

                                    </form>