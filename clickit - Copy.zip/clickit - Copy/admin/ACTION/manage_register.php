<?php
session_start();
include "../config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $a_name = mysqli_real_escape_string($db, $_POST["a_name"]);
    $a_email = mysqli_real_escape_string($db, $_POST["a_email"]);
    $a_phone = mysqli_real_escape_string($db, $_POST["a_phone"]);
    $a_password = password_hash($_POST["a_password"], PASSWORD_BCRYPT);

    // Check if email already exists
    $checkQuery = "SELECT id FROM `admin` WHERE `a_email` = '$a_email'";
    $checkResult = mysqli_query($db, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        $_SESSION['error'] = 'This email is already registered!';
        header("Location: ../register.php");
        exit;
    }

    // Insert user data
    $query = "INSERT INTO `admin` (`a_name`, `a_email`, `a_phone`, `a_password`) VALUES ('$a_name', '$a_email', '$a_phone', '$a_password')";
    
    if (mysqli_query($db, $query)) {
        $_SESSION['success'] = 'Registration successful! You can now login.';
        header("Location: ../register.php");
        exit;
    } else {
        $_SESSION['error'] = 'Something went wrong. Please try again.';
        header("Location: ../register.php");
        exit;
    }
}
?>