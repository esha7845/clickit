<?php
session_start();
include '../config.php'; // Database connection

$submit = $_REQUEST['submit'] ?? ''; // Ensure submit is set
$create_at = date('Y-m-d H:i:s');
$update_at = date('Y-m-d H:i:s');
$session_id = session_id();
switch ($submit) {
    case 'add_to_cart':
        if (!isset($_REQUEST['product_id']) || empty($_REQUEST['product_id'])) {
            die('Invalid request: Product ID is missing.');
        }
    
        $product_id = mysqli_real_escape_string($db, $_REQUEST['product_id']);
        $u_id = isset($_REQUEST['u_id']) ? intval($_REQUEST['u_id']) : 0;
        $quantity = isset($_REQUEST['quantity']) ? intval($_REQUEST['quantity']) : 1;
    
        // Fetch product price from database
        $result = $db->query("SELECT price FROM product WHERE p_id = '$product_id'");
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $price = $row['price']; // Get the price from the database
        } else {
            die('Error: Product not found.');
        }
    
        // Check if the product is already in the cart
        $check = $db->query("SELECT * FROM cart WHERE product_id = '$product_id' AND u_id = '$u_id'");
    
        if ($check->num_rows > 0) {
            // Update quantity if product already exists in cart
            $db->query("UPDATE cart SET quantity = quantity + $quantity, update_at = '$update_at' 
                        WHERE product_id = '$product_id' AND u_id = '$u_id'");
        } else {
            // Insert new product into cart with fetched price
            $db->query("INSERT INTO cart (u_id, session_id, product_id, quantity, price, create_at, update_at) 
                        VALUES ('$u_id', '$session_id', '$product_id', '$quantity', '$price', '$create_at', '$update_at')");
        }
    
        header("Location: ../../index.php?success=Product Added Successfully");
        exit();
    

    case 'remove_selected':
        if (!isset($_POST['selected_products']) || empty($_POST['selected_products'])) {
            die('No products selected for removal.');
        }

        $selected_products = $_POST['selected_products'];
        $product_ids = implode(',', array_map('intval', $selected_products));
        $u_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

        $db->query("DELETE FROM cart WHERE product_id IN ($product_ids) AND u_id = '$u_id'");
        header("Location: ../../index.php?success=Selected Products Removed Successfully");
        exit();

    case 'remove_from_cart':
        if (!isset($_REQUEST['product_id']) || empty($_REQUEST['product_id'])) {
            die('Invalid request: Product ID is missing.');
        }

        $product_id = mysqli_real_escape_string($db, $_REQUEST['product_id']);
        $u_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

        // Remove item from cart for the specific user
        $delete = $db->query("DELETE FROM cart WHERE product_id = '$product_id' AND u_id = '$u_id'");

        if ($delete) {
            header("Location: ../../index.php?success=Product Removed Successfully");
            exit();
        } else {
            echo "Error removing product from cart.";
        }
        break;

    default:
        echo "No action found";
   break;
}
?>
