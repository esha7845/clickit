<?php
include 'config.php';
$submit = $_REQUEST['submit'];
$create_at = date ('y-m-d h:i:s');
$update_at = date ('y-m-d h:i:s');

switch ($submit) {
   case 'submit_form':
      $name = mysqli_real_escape_string($db,$_REQUEST['name']);
      
      $db->query("INSERT INTO `clickit`(`b_id`, `b_name`, `image`, `create_at`)
                       VALUES (NULL,'$name','$image','$create_at')");
                         // Image upload logic
                         $u_id = $db->insert_id;
          if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif","webp","JPG"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Update the table with the file name
                    $db->query("UPDATE clickit SET file = '$filename' WHERE b_id = '$b_id'");
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the image. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
                die();
            }
        }

        header("Location: banner.php");
        break;
      $u_id = $db->insert_id;

      case 'update_form':
        $b_id = mysqli_real_escape_string($db,$_REQUEST['b_id']);
        $b_name = mysqli_real_escape_string($db,$_REQUEST['b_name']);
          $image = mysqli_real_escape_string($db,$_REQUEST['image']);
        // Update base data
        $db->query("UPDATE `clickit`
        SET `name`= '$name', `image` = '$image',
        WHERE   `u_id` = '$u_id'");

          // Image upload logic
          if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $file = $_FILES['file']['name'];
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            $allowedTypes = ["jpg", "jpeg", "png", "gif","webp","JPG"];

            if (in_array(strtolower($ext), $allowedTypes)) {
                $rand = rand(10000, 99999);
                $filename = 'file' . $rand . '.' . $ext;
                $filepath = "uploads/" . $filename;

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) {
                    // Update the table with the file name
                    $db->query("UPDATE clickit SET file = '$filename' WHERE b_id = '$b_id'");
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the image. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Invalid file type! Allowed types: JPG, JPEG, PNG, GIF.</div>';
                die();
            }
        }

        header("Location: banner.php");
        break;
   
    case 'delete':
    $u_id = $_REQUEST['u_id'];
    $db->query("DELETE FROM `clickit` WHERE u_id ='$u_id'");
    header("Location:banner.php");
    break;


    case 'update_form':
    $u_id = mysqli_real_escape_string($db,$_REQUEST['u_id']);
    $name = mysqli_real_escape_string($db,$_REQUEST['name']);
      $image = mysqli_real_escape_string($db,$_REQUEST['image']);
      $db->query("UPDATE `clickit` SET `name`='$name',`image`='$image', WHERE u_id = '$u_id'");
      header("Location:banner.php");


    default:
    echo "No Found";
    break;
}







?>