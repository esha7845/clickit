<?php
include 'config.php';

?>


<?php
session_start();
if (isset($_SESSION["admin_id"])) {
    header("Location: dashboard1.php"); // Redirect logged-in users to the dashboard
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link
        href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #F5F5F5;
            overflow-x: hidden;
        }

        .card {
            background-color: #FFFFFF;
            width: 445px;
            text-align: center;
            margin: 0 auto;
            /* padding: 50px 20px; */
            margin-top: 60px;
            height: 570px;
            border-radius: 7px;
        }

        .card h6 {
            color: #898989;
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            margin-top: 30px;
        }

        .card img {
            width: 200px;
            height: 200px;
            margin-left: 114px;
            margin-top: 29px;
        }

        .form-control {
            width: 390px;
            margin-left: 28px;
            border-radius: 3px;
            background-color: #E8F0FE;
            margin-top: 16px;
        }

        .form-check-label {
            margin-left: -248px;
            margin-top: 15px;

        }

        #exampleCheck1 {
            margin-left: 6px;
            margin-top: 20px;

        }

        .btn {
            width: 128px;
            height: 36px;
            border-radius: 2px;
            margin-top: 22px;
            background-color: #0398DB;
        }

        .text {
            display: flex;
            justify-content: space-between;
            margin-left: 20px;
            margin-top: 20px;
        }
        .text p{
            color: #898989;
        }
        p:hover{
            color: #23527C;
        }
        .text a{
            text-decoration: none;
        }
    </style>

</head>

<body>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://bluecodes.site/meatsale/admin/logo.png" class="img-fluid" alt="...">
                <h6><b>Sign In</b></h6>
                <?php
                    if (isset($_SESSION['error'])) {
                        echo "<div class='alert alert-danger'>" . $_SESSION['error'] . "</div>";
                        unset($_SESSION['error']);
                    }
                    ?>
                <form action="ACTION/manage_login.php" method="POST">
                    <div class="form-group">
                        <input type="email" name="a_email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Username">
                    </div>
                    <div class="form-group">
                        <input type="password" name="a_password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Remember Me</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Log In</button>
        
                    <div class="text">
                       <a href=""> <p><i class="fa-solid fa-lock"></i> Forgot your password?</p></a>
                        <a href="register.php"><p style="margin-right: 25px;">Create an account</p></a>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>
    <!--profile card starts-->
    




    <!-- bootstrap cdn icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>