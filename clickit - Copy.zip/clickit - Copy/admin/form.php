<?php
include 'config.php';
$submit = $_REQUEST['submit'];
$create_at = date ('y-m-d h:i:s');
$update_at = date ('y-m-d h:i:s');


switch ($submit) {
   case 'submit_form':
      $name = mysqli_real_escape_string($db,$_REQUEST['first_name']);
      $name = mysqli_real_escape_string($db,$_REQUEST['last_name']);
      $number = mysqli_real_escape_string($db,$_REQUEST['number']);
      $email = mysqli_real_escape_string($db,$_REQUEST['email']);
      $address = mysqli_real_escape_string($db,$_REQUEST['address']);
      $password = mysqli_real_escape_string($db,$_REQUEST['password']);
      $v_password = md5($password);
      $db->query("INSERT INTO practice(`u_id`, `name`, `address`, `email`, `password`, `creat_at`) VALUES (NULL,'$name','$number','$email','$address','$password','$create_at')");
      header("Location:index.php");
   break;
   
    case 'delete':
    $u_id = $_REQUEST['u_id'];
    $db->query("DELETE FROM `text` WHERE u_id ='$u_id'");
    header("Location:index.php");
    break;


    case 'update_form':
      $name = mysqli_real_escape_string($db,$_REQUEST['first_name']);
      $name = mysqli_real_escape_string($db,$_REQUEST['last_name']);
      $number = mysqli_real_escape_string($db,$_REQUEST['number']);
      $email = mysqli_real_escape_string($db,$_REQUEST['email']);
      $address = mysqli_real_escape_string($db,$_REQUEST['address']);
      $password = mysqli_real_escape_string($db,$_REQUEST['password']);
      $v_password = md5($password);
      $db->query("UPDATE practice(`u_id`, `name`, `address`, `email`, `password`, `creat_at`) VALUES (NULL,'$name','$number','$email','$address','$password','$create_at')");
      header("Location:index.php");


    default:
    echo "No Found";
    break;
}


	 
	
   


   


    default:
    echo "No Found";
    break;
}







?>