<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .dext1 {
            background-color: #03A9F4;
            width: 100%;
            height: 50px;
            margin-left: 0px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;

        }

        .dext {
            margin-top: 18px;
        }

        .dext3 {
            background-color: #03A9F4;
            margin-right: 15px;
            height: 50px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .data1 {
            background-color: #FFFFFF;
            height: 385px;
            margin-left: 15px;

        }

        .form-control {
            width: 360px;
            margin-left: 6px;
        }

        .form-control input {
            text-align: left;
        }

        .st {
            text-align: left;
            margin-left: 10px;
            margin-top: 15px;
        }

        .btnn {
            text-align: left;
            margin-left: 20px;
            margin-top: 20px;
        }

        .btnn button {
            background-color: #20262D;
            color: white;
            width: 85px;
            height: 36px;
            border-radius: 2px;
        }

        .form-label label {
            margin-bottom: 6px;
        }

        .dext1 b {
            margin-left: 20px;
        }

        .dext3 b {
            margin-left: 20px;
        }

        td img {
            width: 287px;
            height: 185px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        table {
            border: "n";
            width: 800px;
            border-collapse: collapse;
            text-align: center;
            margin-left: 10px;
            background-color: #F9F9F9;
            margin-top: 15px;
            color: grey;

        }

        table td {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        table th {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        table tr {
            height: 55px;
        }

        td i {
            width: 150px;

        }

        .ic {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-left: 30px;
        }

        .ic i {
            background-color: red;
            color: white;
            border-radius: 3px;
            width: 41px;
            height: 33px;
            font-size: 12px;
            margin-right: 5px;
            /* margin-top: 10px; */
            /* display: flex;
            align-items: center; */
        }

        .dext4 {
            background-color: #FFFFFF;
            width: 818px;
            height: 622px;
        }

        .dr-list {
            display: flex;
            justify-content: space-between;
        }

        .d-list1 {
            display: flex;
        }

        .d-list2 {
            display: flex;
        }

        .dropdown-menu {
            width: 40px;
        }

        #num {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 93px;
            text-align: left;
            margin-top: 20px;
        }

        .dr-list p {
            margin-left: 20px;
            margin-top: 26px;
        }

        #formGroupExampleInput {
            width: 360px;
            height: 41px;
            border-radius: 3px;
            margin-top: 0px;
            margin-right: 10px;
        }

        .dext5 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 15px;
        }

        .pagin {
            margin-right: 15px;
        }

        #exampleFormControlInput1 {
            width: 182px;
            height: 43px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }

        #formFileMultiple {
            width: 360px;
            height: 40px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }
        #exampleFormControlSelect1{
           margin-left: 10px; 
           width: 417px;
        }
        .card-header{
            background-color: #03A9F4;
        }
    </style>
</head>

<body>

    <div class="row g-0 text-center">
        <div class="col-sm-6 col-md-2">
        <?php include 'sidebar.php';?>
        </div>
        <div class="col-6 col-md-10">
            <div class="menu">
                <div class="row">
                <?php include 'header.php';?>
                    <br>
                    <div class="row">
                        <div class="nav2">
                            <div class="col-md-2">
                                <b>Add Unit</b>
                            </div>
                            <div class="col-md-8"></div>
                            <div class="col-md-2">
                                <p>Dashboard / Unit</p>
                            </div>
                        </div>
                    </div>

                    <div class="dext">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="data1">
                                    <div class="dext1">
                                        <b>Add Unit</b>
                                    </div>
                                    <div class="dext2">
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1" style="    margin-right: 265px; margin-top: 20px;"><b>Select Product</b></label>
                                            <select class="form-control" id="exampleFormControlSelect1">
                                                <option>Select</option>
                                                <option>Mutton Curry cut</option>
                                                <option>River Prawn</option>
                                                <option>Rahu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1" style="    margin-right: 290px; margin-top: 20px;"><b>Select Unit</b></label>
                                            <select class="form-control" id="exampleFormControlSelect1">
                                                <option>Select</option>
                                                <option>500gm</option>
                                                <option>1kg</option>
                                                <option>2kg</option>
                                                <option>12 Pieces</option>
                                                <option>6 Pieces</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleFormControlSelect1" style="    margin-right: 300px; margin-top: 20px;"><b>Price</b></label>
                                            <select class="form-control" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>

                                        <div class="btnn">
                                            <button>Submit</button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="dext3">
                                    <b>View Product Image</b>
                                </div>
                                <div class="dext4">
                                    <div class="dr-list">
                                        <div class="d-list1">
                                            <p>Show</p>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" id="num" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    10
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="#">10</a></li>
                                                    <li><a class="dropdown-item" href="#">35</a></li>
                                                    <li><a class="dropdown-item" href="#">50</a></li>
                                                    <li><a class="dropdown-item" href="#">100</a></li>
                                                </ul>
                                            </div>
                                            <p>entries</p>
                                        </div>
                                        <div class="d-list2">
                                            <p>Search:</p>
                                            <div class="input-group">
                                                <input type="search" class="form-control" id="exampleFormControlInput1"
                                                    placeholder="search">
                                            </div>
                                        </div>
                                    </div>
                                    <table>
                                        <tr>
                                            <th>Sl No</th>
                                            <th>Action</th>
                                            <th>Product Name</th>
                                            <th>Unit</th>
                                            <th>Date of add</th>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>6</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>
                                        <tr>
                                            <td>7</td>
                                            <td>
                                                <div class="ic">
                                                    <a href="">
                                                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                                                    </a>
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td>MuttonCurry cut</td>
                                            <td>1kg</td>
                                            <td>650</td>
                                        </tr>





                                    </table>
                                    <div class="dext5">
                                        <p style="margin-left: 20px;">Showing 1 to 3 of 3 entries</p>
                                        <div class="pagin">
                                            <nav aria-label="...">
                                                <ul class="pagination">
                                                    <li class="page-item disabled">
                                                        <span class="page-link">Previous</span>
                                                    </li>
                                                    <li class="page-item active" aria-current="page">
                                                        <span class="page-link">1</span>
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">Next</a>
                                                    </li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row" style="margin-top: 358px">
                            <?php include 'footer.php';?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>
    </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top: 100px; height: 560px;">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Edit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="margin-left: 6px;">
                    <div class="card-header">
                        <b>Add Video</b>
                    </div>
                    <div class="card-body">
                        
                        <div class="form-group">
                            <label for="exampleFormControlSelect1" style="    margin-right: 265px; margin-top: 20px;"><b>Select Product</b></label>
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option>Select</option>
                                <option>Mutton Curry cut</option>
                                <option>River Prawn</option>
                                <option>Rahu</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1" style="    margin-right: 265px; margin-top: 20px;"><b>Select Product</b></label>
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option>Select</option>
                                <option>Mutton Curry cut</option>
                                <option>River Prawn</option>
                                <option>Rahu</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="videoName" style="margin-right: 370px;" class="form-label">Name</label>
                            <input type="text" class="form-control" style="width: 420px;" id="videoName"
                                placeholder="Enter video name">
                        </div>
                        
                        
                    </div>
                </div>
            </div>
            <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Understood</button>
            </div> -->
            <button class="btnn btn-primary" style="background-color: black;     border-radius: 3px;
                        background-color: black;
                        color: white;
                        width: 98px;
                        height: 37px;
                        text-align: center;
                        margin-left: 200px;
                        margin-bottom: 75px;
                        ">Submit</button>
        </div>
    </div>
</div>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>