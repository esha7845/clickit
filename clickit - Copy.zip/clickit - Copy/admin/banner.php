<?php
include 'config.php';
?>
<?php
session_start();
if (!isset($_SESSION["admin_id"])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit;
}
?>
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .dext1 {
            background-color: #03A9F4 ;
            width: 100%;
            height: 50px;
            margin-left: 0px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;

        }

        .dext {
            margin-top: 18px;
        }

        .dext3 {
            background-color: #03A9F4;
            margin-right: 15px;
            height: 50px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .data1 {
            background-color: #FFFFFF;
            height: 310px;
            margin-left: 15px;

        }

        .form-control {
            width: 360px;
            margin-left: 6px;
        }

        .form-control input {
            text-align: left;
        }

        .st {
            text-align: left;
            margin-left: 10px;
            margin-top: 15px;
        }

        .btnn {
            text-align: left;
            margin-left: 20px;
        }

        .btnn button {
            background-color: #20262D;
            color: white;
            width: 85px;
            height: 36px;
            border-radius: 2px;
        }

        .form-label label {
            margin-bottom: 6px;
        }

        .dext1 b {
            margin-left: 20px;
        }

        .dext3 b {
            margin-left: 20px;
        }

        td img {
            width: 414px;
            height: 121px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        table {
            border: "n";
            width: 800px;
            border-collapse: collapse;
            text-align: center;
            margin-left: 10px;
            background-color: #F9F9F9;
            margin-top: 15px;
            color: grey;

        }

        table td {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        table th {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        td i {
            width: 150px;

        }

        .ic {
            display: flex;
            /* justify-content: space-around; */
            align-items: center;
            margin-left: 30px;
        }

        .ic i {
            background-color: red;
            color: white;
            border-radius: 3px;
            width: 41px;
            height: 33px;
            font-size: 12px;
            margin-right: 5px;
            /* margin-top: 10px; */
            /* display: flex;
            align-items: center; */
        }

        .dext4 {
            background-color: #FFFFFF;
            width: 817px;
            height: 650px;
        }

        .dr-list {
            display: flex;
            justify-content: space-between;
        }

        .d-list1 {
            display: flex;
        }

        .d-list2 {
            display: flex;
        }

        .dropdown-menu {
            width: 40px;
        }

        #num {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 93px;
            text-align: left;
            margin-top: 20px;
        }

        .dr-list p {
            margin-left: 20px;
            margin-top: 26px;
        }

        #formGroupExampleInput {
            width: 360px;
            height: 41px;
            border-radius: 3px;
            margin-top: 0px;
            margin-right: 10px;
        }

        .dext5 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 15px;
        }

        .pagin {
            margin-right: 15px;
        }

        #exampleFormControlInput1 {
            width: 182px;
            height: 43px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }
        #formFileMultiple{
            width: 360px;
            height: 40px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px; 
        }
        .card-header{
            background-color: #03A9F4;
        }
        /* .btn button{
            margin-top: 20px;
        } */
    </style>
</head>

<body>

    <div class="row g-0 text-center">
        <div class="col-sm-6 col-md-2">
        <?php include 'sidebar.php';?>
        </div>
        <div class="col-6 col-md-10">
            <div class="menu">
                <div class="row">
                <?php include 'header.php';?>
                    <br>
                    <div class="row">
                        <div class="nav2">
                            <div class="col-md-2">
                                <b>Add dextop banner</b>
                            </div>
                            <div class="col-md-8"></div>
                            <div class="col-md-2">
                                <p>Dashboard / dextop banner</p>
                            </div>
                        </div>
                    </div>

                    <div class="dext">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="data1">
                                    <div class="dext1">
                                        <b>Add dextop Banner</b>
                                    </div>
                                    <form action="ACTION/manage_banner.php" method="POST" enctype="multipart/form-data">
                                    <div class="st">
                                                <label >Category Name</label>
                                                <input type="text" class="form-control" name="b_name" required
                                                    placeholder="Name">
                                            </div>
                                            <div class="st">
                                                <label >Upload Image <b
                                                        style="color: red;">1000 *1000</b>
                                                </label>
                                                <input class="form-control" type="file" name="file" required>
                                            </div>
   
    
    <input type="hidden" name="submit" value="submit_form">
    <button type="submit"  class="btn btn-dark">Submit</button>
</form>

                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="dext3">
                                    <b>View Banner dextop</b>
                                </div>
                                <div class="dext4">
                                    <div class="dr-list">
                                        <div class="d-list1">
                                            <p>Show</p>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" id="num" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    10
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="#">10</a></li>
                                                    <li><a class="dropdown-item" href="#">35</a></li>
                                                    <li><a class="dropdown-item" href="#">50</a></li>
                                                    <li><a class="dropdown-item" href="#">100</a></li>
                                                </ul>
                                            </div>
                                            <p>entries</p>
                                        </div>
                                        <div class="d-list2">
                                            <p>Search:</p>
                                            <div class="input-group">
                                                <input type="search" class="form-control" id="exampleFormControlInput1"
                                                    placeholder="search">
                                            </div>
                                        </div>
                                    </div>
                                    <table>
                                        <thead>
                                        <tr>
                                            <th>Sl No</th>
                                            <th>Action</th>
                                            <th>Name</th>
                                            <th>image</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                         <?php
                $sl = 0;
                $data = $db->query("SELECT * FROM `banner`");
                $check = $data->num_rows;
                if ($check == 0) {
                ?>
                    <tr>
                        <td colspan="6" class="text-center">No Data Found</td>
                    </tr>
                <?php
                } else {
                    while ($value = $data->fetch_object()) {
                        $sl++;
                ?>
                                        <tr>
                                            <td><?= $sl; ?></td>
                                            <td>
                                                <div class="ic">
                                                    

                                                         <form action="ACTION/manage_banner.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this banner?');">
    <input type="hidden" name="submit" value="delete">
    <input type="hidden" name="b_id" value="<?= $value->b_id ?>">
    <button type="submit" class="btn btn-sm">
        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
    </button>
</form>

                                                        
                                                   
                                                    <!-- Trigger Button for Modal -->
                                                    <button type="button" class="btn btn-sm" id="icon"
                                                        data-bs-toggle="modal" data-bs-target="#staticBackdrop<?= $value->b_id ?>">
                                                        <i class="fa-solid fa-pen"
                                                            style="background-color: #01A185; padding: 9px 15px;"></i></button>
                                                </div>
                                            </td>

                                            <td><?= htmlspecialchars($value->b_name); ?></td>
                                            <td><?php 
                            if (empty($value->file)) {
                                echo '<img src="uploads/default.jpg" style="width: 80px; height: 80px;" alt="Default Image"/>';
                            } else {
                                echo '<img src="../uploads/' . htmlspecialchars($value->file) . '" style="width: 150px; height: auto;" alt="User Image"/>';
                            }
                            ?></td>
                                        </tr>
                                        <!-- Edit ,odal for each banner -->
  <!-- Modal -->
  <div class="modal fade" id="staticBackdrop<?= $value->b_id ?>" data-bs-backdrop="static" data-bs-keyboard="false"
     tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content" style="margin-top: 100px; height: 560px;">
             <div class="modal-header">
                 <h5 class="modal-title" id="staticBackdropLabel">Edit</h5>
                 <button type="button" class="btn-close" data-bs-dismiss="modal"
                     aria-label="Close">
                 </button>
             </div>
             <div class="modal-body">
                 <div class="card" style="margin-left: 6px;">
                     <div class="card-header">
                         <b>Add Video</b>
                     </div>
                     <form action="ACTION/manage_banner.php" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="submit" value="update_form">
                                <input type="hidden" name="b_id" value="<?= $value->b_id ?>">

                                <!-- <div class="modal-header">
                                    <h5 class="modal-title">Edit Offer Banner</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div> -->
                                <div class="modal-body">
                                    <label>Banner Name</label>
                                    <input type="text" name="b_name" class="form-control" value="<?= htmlspecialchars($value->b_name); ?>" required>

                                    <label>Upload New Image</label>
                                    <input type="file" name="file" class="form-control">
                                    <p><small>Leave blank to keep the existing image.</small></p>
                                    
                                    <div>
                                        <label>Current Image:</label><br>
                                        <img src="../uploads/<?= htmlspecialchars($value->file); ?>" style="width: 150px; height: auto;" alt="Banner Image">
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
         </div>
                                     <?php } } ?>
                                    </tbody>
                                       
                                    </table>
                                    <div class="dext5">
                                        <p style="margin-left: 20px;">Showing 1 to 3 of 3 entries</p>
                                        <div class="pagin">
                                            <nav aria-label="...">
                                                <ul class="pagination">
                                                    <li class="page-item disabled">
                                                        <span class="page-link">Previous</span>
                                                    </li>
                                                    <li class="page-item active" aria-current="page">
                                                        <span class="page-link">1</span>
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">Next</a>
                                                    </li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row" style="margin-top: 358px">
                            <?php include 'footer.php';?>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>


    </div>
    </div>
    </div>
   
     </div>
 </div>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>