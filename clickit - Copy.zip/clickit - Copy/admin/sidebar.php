<div class="sidebar">
                <div class="logo">
                    <img src="https://bluecodes.site/meatsale/admin/assets/images/logo_white_2.png" alt="">
                </div>
                <div class="pic">
                    <img src="https://bluecodes.site/meatsale/admin/pages/uploads/a56f469ea41e81de676c94f47eba2e95.png"
                        alt="">
                </div>
                <div class="bt">
                    <div class="dropdown">
                        <button class="btn btn-secondary " style="background-color: #2A323C; border: #2A323C;"
                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <b>YUMCUT</b>
                        </button>
                        <ul class="dropdown-menu">
                            <li><button class="dropdown-item" type="button">Action</button></li>
                            <li><button class="dropdown-item" type="button">Another action</button></li>
                            <li><button class="dropdown-item" type="button">Something else here</button></li>
                            <hr>
                            <li><button class="dropdown-item" type="button">Another action</button></li>
                        </ul>
                    </div>
                </div>
                <div class="btt">
                    <ul class="list-group">
                        <li class="list-group-item"
                            style="background-color: #2A323C; width: 240px; color: white; border: #2A323C;">
                            <input class="form-check-input me-1" type="radio" name="listGroupRadio" value=""
                                id="firstRadio" checked>
                            <label class="form-check-label" for="firstRadio">Online</label>
                        </li>
                </div>
                <div class="list">
                    <div class="accordion" id="accordionPanelsStayOpenExample">
                        <div class="accordion-item" style="border: #2A323C; border-bottom: #2A323C;">
                            <h2 class="accordion-header">
                                <button class="accordion-button" style="border-bottom: #2A323C;" id="accolist"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne"
                                    aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                                    <i class="fa-solid fa-house"></i> &nbsp; <a href="dashboard1.php" style="text-decoration: none; color: white;">Dashboard</a>
                                    
                                </button>
                            </h2>

                        </div>

                        <a href="dashboard1.php">Dashboard</a>
                        <div class="accordion-item" style="border: #2A323C;">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" id="accolist" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo"
                                    aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
                                    <i class="fa-solid fa-sitemap"></i> &nbsp; Page section
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse">
                                <div class="accordion-body">
                                    <ul>
                                        <a href="dextop.php">
                                            <li>Add Dextop Banner</li>
                                        </a>
                                        <a href="mobile.php">
                                            <li>Add Mobile Banner</li>
                                        </a>
                                        <a href="testimonial.php">
                                            <li>Add Testimonial</li>
                                        </a>
                                        <a href="location.php">
                                            <li>Add Location</li>
                                        </a>
                                        <a href="banner.php">
                                            <li>Add Offer Banner</li>
                                        </a>
                                        <a href="video.php">
                                            <li>Add Video</li>
                                        </a>



                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" style="border: #2A323C;">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" id="accolist" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree"
                                    aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
                                    <i class="fa-solid fa-sitemap"></i> &nbsp; Order section
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse">
                                <div class="accordion-body">
                                    <ul>
                                        <a href="view.php">
                                            <li>View Order</li>
                                        </a>
                                        <a href="complete.php">
                                            <li>View Complete Order</li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" style="border: #2A323C;">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" id="accolist" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseFour"
                                    aria-expanded="false" aria-controls="panelsStayOpen-collapseFour">
                                    <i class="fa-solid fa-sitemap"></i> &nbsp; Product section
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse">
                                <div class="accordion-body">
                                    <ul>
                                        <a href="promo.php">
                                            <li>Add promo code</li>
                                        </a>
                                        <a href="category.php">
                                            <li>Add category</li>
                                        </a>
                                        <a href="subcategory.php">
                                            <li>Add subcategory</li>
                                        </a>
                                        <a href="product.php">
                                            <li>Add Product</li>
                                        </a>
                                        <a href="extraproduct.php">
                                            <li>Add product extra image</li>
                                        </a>
                                        <a href="unit.php">
                                            <li>Add unit</li>
                                        </a>
                                        <a href="price.php">
                                            <li>Add price</li>
                                        </a>
                                        <a href="offer.php">
                                            <li>Add Offer</li>
                                        </a>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>