<div class="nav">
                        <div class="col-md-1">
                            <div class="icn1">
                                <i class="fa-solid fa-bars"></i>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="srh">
                                <div class="input-group">
                                    <input type="search" class="form-control" id="exampleFormControlInput1"
                                        placeholder="search">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7"></div>
                        <div class="col-md-2">
                            <div class="icn2">
                                <a href=""><i class="fa-solid fa-bell"></i></a>
                                <a href=""><i class="fa-solid fa-minimize"></i></a>
                                <div class="dropdown">
                                    <button class="btn btn-secondary "
                                        style="background-color: #03A9F4; border: #03A9F4;" type="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <img src="https://bluecodes.site/meatsale/admin/pages/uploads/a56f469ea41e81de676c94f47eba2e95.png"
                                            alt="">
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><button class="dropdown-item" type="button">Action</button></li>
                                        <li><button class="dropdown-item" type="button">Another action</button></li>
                                        <li><button class="dropdown-item" type="button">Something else here</button>
                                        </li>
                                        <hr>
                                        <li><button class="dropdown-item" type="button">Another action</button></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>