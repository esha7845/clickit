
 <?php
include 'config.php';

?>
<?php
session_start();
if (!isset($_SESSION["admin_id"])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .dext3 {
            background-color: #03A9F4;
            margin-right: 15px;
            height: 50px;
            color: #FFFFFF;
            text-align: left;
            display: flex;
            align-items: center;
        }

        .dext3 b {
            margin-left: 20px;
        }

        .vw {
            margin-left: 20px;
            margin-top: 10px;
        }

        .st {
            text-align: left;
            margin-left: 10px;
            margin-top: 15px;
        }

        .btnn {
            text-align: left;
            margin-left: 20px;
            margin-bottom: 20px;

        }

        .btnn button {
            background-color: #01A185;
            color: white;
            width: 85px;
            height: 36px;
            border-radius: 2px;
            border: #01A185;
            margin-bottom: -9px;

        }

        .form-label label {
            margin-bottom: 6px;
        }

        .dext1 b {
            margin-left: 20px;
        }

        .dext3 b {
            margin-left: 20px;
        }

        td img {
            width: 287px;
            height: 185px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        table {
            border: "n";
            width: 1203px;
            border-collapse: collapse;
            text-align: left;
            margin-left: 10px;
            background-color: #F9F9F9;
            margin-top: 15px;
            color: grey;

        }

        table td {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        table th {
            border-top: 1px solid rgb(237, 229, 229);
            border-left: 1px solid rgb(237, 229, 229);
            border-right: 1px solid rgb(237, 229, 229);
            border-bottom: 1px solid rgb(237, 229, 229);
        }

        td i {
            width: 150px;

        }

        .ic {
            display: flex;
            /* justify-content: space-around; */
            align-items: center;
            margin-left: 30px;
        }

        .ic i {
            background-color: red;
            color: white;
            border-radius: 3px;
            width: 41px;
            height: 33px;
            font-size: 12px;
            margin-right: 5px;
            /* margin-top: 10px; */
            /* display: flex;
            align-items: center; */
        }

        .dext4 {
            background-color: #FFFFFF;
            width: 1222px;
            height: 520px;
            /* display: flex; */
        }

        .dextn {
            background-color: #FFFFFF;
            width: 1222px;
            height: 520px;
            display: flex;
        }

        .dext-n {
            background-color: #FFFFFF;
            width: 1222px;
            height: 520px;
            display: flex;
        }

        .dr-list {
            display: flex;
            justify-content: space-between;
        }

        .d-list1 {
            display: flex;
        }

        .d-list2 {
            display: flex;
        }

        .dropdown-menu {
            width: 40px;
        }

        #num {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 93px;
            text-align: left;
            margin-top: 20px;
        }

        .dr-list p {
            margin-left: 20px;
            margin-top: 26px;
        }

        #formGroupExampleInput {
            width: 386px;
            height: 40px;
            border-radius: 3px;
            margin-top: 0px;
            margin-right: 10px;
            margin-left: -8px;
        }

        .dext5 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 15px;
        }

        .pagin {
            margin-right: 15px;
        }

        #exampleFormControlInput1 {
            width: 182px;
            height: 43px;
            margin-top: 17px;
            margin-right: 10px;
            border-radius: 3px;
        }

        #formFileMultiple {
            width: 360px;
            height: 39px;
            margin-top: 2px;
            margin-right: 10px;
            border-radius: 3px;
        }

        #num-1 {
            background-color: #FFFFFF;
            border: 1px solid rgb(237, 229, 229);
            color: black;
            border-radius: 3px;
            margin-left: 10px;
            width: 132px;
            text-align: left;
            /* margin-top: 10px; */
            margin-right: 20px;
            margin-bottom: 10px;
        }

        .card-header {
            background-color: #03A9F4;
        }

        .sel {
            width: 360px;
        }
        .frm b{
            padding-right: 240px;
            margin-bottom: 10px;
        }
        .frm{
            margin-top: 20px;

        }
        #floatingTextarea2 textarea{
            height: 300px;
        }
        /* .bttn3{
            color: white;
            background-color: black;
        
        } */
        .select{
            background-color: #FFFFFF;
        }
        .menu{
            height: 110vh;
        }
        .vw{
            margin-top: 20px;
        }
        .dbtn {
            margin-right: 313px;
            /* width: 360px; */
        }
        .dbtn button{
            width: 115px;
            background-color: black;
            

        }


        
    </style>
</head>

<body>

    <div class="row g-0 text-center">
        <div class="col-sm-6 col-md-2">
        <?php include 'sidebar.php';?>
        </div>
        <div class="col-6 col-md-10">
            <div class="menu">
                <div class="row">
                <?php include 'header.php';?>
                    <br>
                    <div class="row">
                        <div class="nav2">
                            <div class="col-md-2">
                                <b>view product</b>
                            </div>
                            <div class="col-md-8"></div>
                            <div class="col-md-2">
                                <p>Dashboard / product </p>
                            </div>
                        </div>
                    </div>
                    <br>



                    <div class="row">
                        <div class="vw">
                            <div class="col-md-12">
                                <div class="dext3">
                                    <b>view product</b>
                                </div>
                                <div class="select">
                                <div class="row">
                                    <div class="col-md-4">
                                    <?php


            // Fetch categories for dropdown
            $categories = $db->query("SELECT * FROM `category`");

            $sub_categories = $db->query("SELECT * FROM `subcategory`");
            ?>
            <form action="ACTION/manage_product.php" method="POST" enctype="multipart/form-data">
                <!-- Category Selection -->
                <label for="categorySelect"><b>Select Category</b></label>
                <select class="form-control" name="c_id" id="categorySelect" required>
                    <option value="">Select</option>
                    <?php while ($cat = $categories->fetch_object()) { ?>
                        <option value="<?= $cat->c_id ?>"><?= htmlspecialchars($cat->c_name) ?></option>
                    <?php } ?>
                </select>

                <!-- Subcategory Selection -->
                <label for="categorySelect"><b>Select Sub-Category</b></label>
                <select class="form-control" name="s_id" id="categorySelect" required>
                    <option value="">Select</option>
                    <?php while ($scat = $sub_categories->fetch_object()) { ?>
                        <option value="<?= $scat->s_id ?>"><?= htmlspecialchars($scat->sub_name) ?></option>
                    <?php } ?>
                </select>

                <!-- Product Name -->
                <div class="mb-3">
                    <label for="productName" class="form-label"><b>Product Name</b></label>
                    <input type="text" name="p_name" class="form-control" id="productName" placeholder="Product Name" required>
                </div>
                <div class="mb-3">
                    <label for="productPrice" class="form-label"><b>Selling Price</b></label>
                    <input type="number" name="price" class="form-control" id="productPrice" placeholder="Selling Price" required>
                </div>
                
                <div class="mb-3">
                    <label for="productPrice" class="form-label"> <b>Market Price</b></label>
                    <input type="number" name="m_price" class="form-control" id="productPrice" placeholder="Market Price" required>
                </div>
                <div class="mb-3">
                    <label for="productPrice" class="form-label"><b>Unit</b></label>
                    <input type="text" name="unit" class="form-control" id="productPrice" placeholder="Unit" required>
                </div>
                <!-- Product Image Upload -->
                <div class="mb-3">
                    <label for="productImage" class="form-label"><b>Upload Image</b> <b style="color: red;">1000x1000</b></label>
                    <input class="form-control" name="file" type="file" id="productImage" required>
                </div>
                <div class="dropdown dbtn">
                <label for="stock"><b>Stock</b></label>
<select class="form-control" name="stock" id="stock" required>
    <option value="in_stock">In Stock</option>
    <option value="out_stock">Out of Stock</option>
</select>
</div>


                <!-- Product Description -->
                <h6><b>Description</b></h6>
                <div class="form-floating">
                    <textarea class="form-control" name="description" placeholder="Enter product description" id="floatingTextarea2" style="height: 110px"></textarea>
                </div>
                

                <div class="btnn">
                    <button type="submit" name="submit" value="submit_form" class="btn btn-primary"><b>Submit</b></button>
                </div>
            </form>

<!-- jQuery for AJAX -->
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#categorySelect').change(function() {
        var categoryId = $(this).val();
        if (categoryId) {
            $.ajax({
                type: 'POST',
                url: 'fetch_subcategories.php',
                data: { c_id: categoryId },
                success: function(response) {
                    $('#subCategorySelect').html(response);
                }
            });
        } else {
            $('#subCategorySelect').html('<option value="">Select Category First</option>');
        }
    });
});
</script> -->


                                
                                    
                               


                                
                            </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="vw">
                    <div class="col-md-12">
                        <div class="dext3">
                            <b>View product</b>
                        </div>
                        <div class="dext4">
                            <div class="dr-list">
                                <div class="d-list1">
                                    <p>Show</p>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" id="num" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            10
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#">10</a></li>
                                            <li><a class="dropdown-item" href="#">35</a></li>
                                            <li><a class="dropdown-item" href="#">50</a></li>
                                            <li><a class="dropdown-item" href="#">100</a></li>
                                        </ul>
                                    </div>
                                    <p>entries</p>
                                </div>
                                <div class="d-list2">
                                    <p>Search:</p>
                                    <div class="input-group">
                                        <input type="search" class="form-control" id="exampleFormControlInput1"
                                            placeholder="search">
                                    </div>
                                </div>
                            </div>
                            <table class="table">
                            <thead>
    <tr>
        <th>Sl No</th>
        <th>Action</th>
        <th>Category Name</th>
        <th>Subcategory Name</th>
        <th>Product</th>
        <th>Image</th>
        <th>selling Price</th>
        <th>market Price</th>
        <th>unit</th>
        <th>stock</th>
        <th>Description</th>
        <th>Date and Time</th>
    </tr>
</thead>
<tbody>
    <?php
    $query = "SELECT p.*, c.c_name, s.sub_name FROM product p
              INNER JOIN category c ON p.c_id = c.c_id
              INNER JOIN subcategory s ON p.s_id = s.s_id";
    $result = $db->query($query);
    $sl = 1;

    while ($row = $result->fetch_assoc()) {
    ?>
        <tr>
            <td><?= $sl++; ?></td>
            <td>
                <div class="ic">
                    <!-- Delete -->
                    <a href="ACTION/manage_product.php?submit=delete&p_id=<?= $row['p_id']; ?>" onclick="return confirm('Are you sure?')">
                        <i class="fa-solid fa-trash" style="padding: 9px 15px;"></i>
                    </a>
                    <!-- Edit -->
                    <button type="button" class="btn btn-sm" id="icon" data-bs-toggle="modal"
                        data-bs-target="#editModal<?= $row['p_id']; ?>">
                        <i class="fa-solid fa-pen" style="background-color: #01A185; padding: 9px 15px;"></i>
                    </button>
                </div>
            </td>
            <td><?= htmlspecialchars($row['c_name']); ?></td>
            <td><?= htmlspecialchars($row['sub_name']); ?></td>
            <td><?= htmlspecialchars($row['p_name']); ?></td>
            <td>
                <?php if (!empty($row['image'])) { ?>
                    <img src="../uploads/<?= $row['image']; ?>" width="50" height="50">
                <?php } ?>
            </td>
            <td><?= htmlspecialchars($row['price']); ?></td>
            <td><?= htmlspecialchars($row['m_price']); ?></td>
            <td><?= htmlspecialchars($row['unit']); ?></td>
            <td><?= htmlspecialchars($row['stock']); ?></td>
            <td><?= htmlspecialchars($row['description']); ?></td>
            <td><?= $row['create_at']; ?></td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal<?= $row['p_id']; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" style="margin-top: 100px; height: auto;">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="ACTION/manage_product.php" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <input type="hidden" name="p_id" value="<?= $row['p_id']; ?>">

                            <!-- Select Category -->
                            <label for="categorySelect<?= $row['p_id']; ?>"><b>Select Category</b></label>
                            <select class="form-control" name="c_id" id="categorySelect<?= $row['p_id']; ?>" required>
                                <option value="">Select</option>
                                <?php
                                $catQuery = $db->query("SELECT * FROM category");
                                while ($cat = $catQuery->fetch_object()) {
                                    $selected = ($cat->c_id == $row['c_id']) ? 'selected' : '';
                                    echo "<option value='{$cat->c_id}' $selected>{$cat->c_name}</option>";
                                }
                                ?>
                            </select>

                            <!-- Select Subcategory -->
                            <label for="subcategorySelect<?= $row['p_id']; ?>"><b>Select Sub-Category</b></label>
                            <select class="form-control" name="s_id" id="subcategorySelect<?= $row['p_id']; ?>" required>
                                <option value="">veg</option>
                                <option value="">non-veg</option>
                                <!-- <option value="">non-veg</option> -->
                                <?php
                                $subQuery = $db->query("SELECT * FROM subcategory WHERE c_id = '{$row['c_id']}'");
                                while ($sub = $subQuery->fetch_object()) {
                                    $selected = ($sub->s_id == $row['s_id']) ? 'selected' : '';
                                    echo "<option value='{$sub->s_id}' $selected>{$sub->sub_name}</option>";
                                }
                                ?>
                            </select>
                            <div class="mb-3">
                                <label class="form-label">Product Name</label>
                                <input type="text" name="p_name" class="form-control" value="<?= htmlspecialchars($row['p_name']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">SellingPrice</label>
                                <input type="number" name="price" class="form-control" value="<?= htmlspecialchars($row['price']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Market Price</label>
                                <input type="number" name="m_price" class="form-control" value="<?= htmlspecialchars($row['m_price']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Unit</label>
                                <input type="text" name="unit" class="form-control" value="<?= htmlspecialchars($row['unit']); ?>" required>
                            </div>
                            <div class="dropdown dbtn">
                <label for="stock"><b>Stock Status</b></label>
<select class="form-control" name="stock" id="stock" required>
    <option value="in_stock">In Stock</option>
    <option value="out_stock">Out of Stock</option>
</select>
</div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description"><?= htmlspecialchars($row['description']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Upload New Image (optional)</label>
                                <input class="form-control" type="file" name="file">
                            </div>
                        

                            <input type="hidden" name="submit" value="update_form">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    <?php } ?>
</tbody>
                            </table>


                            <div class="dext5">
                                <p style="margin-left: 20px;">Showing 1 to 3 of 3 entries</p>
                                <div class="pagin">
                                    <nav aria-label="...">
                                        <ul class="pagination">
                                            <li class="page-item disabled">
                                                <span class="page-link">Previous</span>
                                            </li>
                                            <li class="page-item active" aria-current="page">
                                                <span class="page-link">1</span>
                                            </li>
                                            <li class="page-item">
                                                <a class="page-link" href="#">Next</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
            </div>
        </div>
    </div>
    </div>


    </div>
    </div>
    </div>
    <!-- Modal -->
    



    
                            <?php include 'footer.php';?>
                            


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>

