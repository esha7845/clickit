<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Funnel+Display:wght@300..800&family=SUSE:wght@100..800&display=swap"
        rel="stylesheet">

    <style>
        * {
            margin: 0px;
            padding: 0px;
        }



        .logo img {
            width: 145px;
            height: 43px;
            margin-left: 10px;
        }

        .main-image img {
            width: 83%;
            height: 100%;
            margin-left: 140px;
        }

        .image1 {
            width: 70%;
            margin-left: 165px;
            display: flex;

        }

        .image1 img {
            width: 95%;

        }

        .im-2 {
            margin-left: 10px;
        }

        .im-3 {
            margin-left: 10px;
        }

        input {
            width: 200px;
            height: 45px;
            border-radius: 10px;
            /* border: 1px solid grey; */
            border: 1px solid rgb(188, 184, 184);
        }

        .text2 a {
            text-decoration: none;
            color: rgb(22, 21, 21);

        }

        .btn button {
            background-color: rgb(0, 118, 0);
            color: white;
            width: 100px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .col-md-1 img {
            width: 100px;
            height: 46px;
            padding-top: 12px;
            margin-bottom: 10px;
            margin: -12 7px;
        }

        /* .col-md-2 h6 {
            flex-direction: row;
        } */

        .col-md-2 button {
            margin-left: 9px;
        }

        .col-md-1 {
            text-align: center;
            margin-top: 10px;
        }

        .row {
            width: 100%;
            height: 100%;
            display: flex;
            /* border-bottom: 1px solid rgb(230, 230, 230); */
            margin-top: 10px;

        }

        .image img {
            width: 83%;
            height: 100%;
            margin-left: 140px;
            margin-top: 10px;
        }

        .image-1 {
            width: 89%;
            margin-left: 165px;
            height: 100%;
            display: flex;


        }

        .image-1 img {
            width: 95%;

        }

        .image-2 img {
            width: 116px;
            height: 173px;
        }

        .image-3 img {
            width: 116px;
            height: 173px;
        }

        .mycontainer2 {
            max-width: 100%;
            overflow: auto hidden;
            scrollbar-width: none;
            display: flex;
            flex-direction: row;
            -webkit-box-align: center;
            align-items: center;
            padding-bottom: 20px;
            column-gap: 20px;
            margin-left: 30px;
            margin-right: 12px;


        }

        .btn button {
            background-color: green;
            color: white;
            width: 80px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .col-md-5 {
            display: flex;
            gap: 5rem;
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        /* .row {
            margin-top: 20px;
        } */

        .col-md-4 {
            display: flex;
            gap: 2rem;
        }

        b {
            font-family: "Parkinsans", sans-serif;
            font-weight: 900px;
            font-size: 18px;
            /* font-family: "Kanit", sans-serif;
            font-family: "Kanit", sans-serif;
            font-weight: 900; */
        }

        .text-1 a {
            text-decoration: none;
        }

        .h6 {
            font-family: "Palanquin Dark", sans-serif;
        }


        .text2 a {
            text-decoration: none;
            color: rgb(22, 21, 21);

        }

        .btn button {
            background-color: green;
            color: white;
            width: 100px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .cal-md-6 {
            width: 600px;
            height: 600px;
            margin-left: 55px;
        }

        .cal-md-6 img {
            width: 100%;
            height: 90%;
        }

        .row {
            display: flex;
            justify-content: space-around;
            width: 100%;
            height: 100%;
            margin-top: 20px;
            /* margin-left: 20px; */
            /* margin-left: 40px; */
            /* border: 1px solid grey; */
        }

        h3 {
            color: green;
        }

        .box1 {
            width: 103px;
            height: 73px;
            border: 2px solid green;
            border-radius: 10px;
            text-align: center;
            margin-top: -7px;
            margin-right: 10px;
        }
        .box1:hover{
            background-color: rgb(215, 240, 215);
            color: green;
        }

        .box {
            width: 43%;
            display: flex;
            justify-content: space-between;
            margin: 2px;
        }

        button {
            margin-bottom: 5px;
            color: green;
            background-color: green;
            background: transparent;
            border-radius: 5px;
            width: 60px;
            height: 30px;
            border: 1px solid green;
        }


        .service-1 {
            display: flex;
            justify-content: space-between;
        }

        .srv-1 img {
            width: 79px;
            height: 62px;
        }

        .srv-2 {
            margin-left: 20px;
        }

        /* h5 {
            text-decoration: none;
            color: rgb(12, 131, 31);
            font-size: 18px;
            line-height: 24px;
            /* font-family: Okra-Medium; */
        /* } */ 

        footer {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-top: -7px;
            font-size: 15px;
            color: rgb(0, 0, 0);
            height: 40vh;
        }

        .tx {
            display: flex;
            justify-content: space-between;
        }



        .container-2 {
            text-align: center;
        }

        .col-md-5 {
            display: flex;
            gap: 5rem;
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        .head {
            /* margin-top: 140px; */
            margin-top: 119px;
            margin-left: 42px;
            margin-bottom: -54px;
        }

        .col-md-4 {
            display: flex;
            gap: 2rem;
        }
        .download img{
        width: 254px;
       }
    </style>
</head>
    <?php include 'header.php';?>
<body  style="margin: 0; padding: 0; overflow-x: hidden;">
    



    <!-- <div class="container-2" style="border-bottom: 1px solid rgb(230, 230, 230); box-shadow: 0px 4px 10px -7px;">
        <nav class="navbar navbar-expand-lg bg-body-tertiary" style="margin-left: 250px;">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Vehetables & Fruits</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Dairy & Breakfast</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Munchies</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Cold Drinks & Juices</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Tea, Coffee & Health Drinks</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Backery & Biscuits</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                More
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Sweet Tooth</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Atta, Rice & dal</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Dry Fruits, Masala & Oil</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Sauces & Spreads</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Chicken, Meat & Fish</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Paan Corner</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Organic & Premium</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Baby Care</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="#">Pharma & Wellness</a></li>
                                <hr>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
    </div> -->

    </nav>
    <div class="container-fluid" style="display: flex;">

        <div class="row">
            <div class="col-md-6">
                <img src="https://www.bigbasket.com/media/uploads/p/xl/104864-2_2-amul-butter-pasteurised.jpg" id="get_src"
                    class="img-fluid">

                <div class="row mt-3" style="height: 70%;">
                    <div class="col-md-2">
                        <img src="https://mcprod.spencers.in/media/catalog/product/1/2/1260586_1.jpg" class="img-fluid"
                            onclick="change_image(this.src)">
                    </div>

                    <div class="col-md-2">
                        <img src="https://img.cdnx.in/372005/amul-gold-full-cream-fresh-milk-1718705295678_SKU-6523_0.jpg?width=600&format=webp"
                            onclick="change_image(this.src)" class="img-fluid">
                    </div>


                    <div class="col-md-2">
                        <img src="https://www.spencers.in/media/catalog/product/1/2/1260586_3.jpg"
                            onclick="change_image(this.src)" class="img-fluid">
                    </div>


                    <div class="col-md-2">
                        <img src="https://m.media-amazon.com/images/I/51xDwKRnT3L._AC_UF350,350_QL80_.jpg"
                            class="img-fluid" onclick="change_image(this.src)">
                    </div>

                    <div class="col-md-2">
                        <img src="https://img.thecdn.in/23327/1624109906447_SKU-0755_0.jpg?width=600" class="img-fluid"
                            onclick="change_image(this.src)">
                    </div>



                </div>

            </div>




            <div class="col-md-6" style="margin-top: 25px;">
                <p>Home / Milk / Amul Gold Full Cream Fresh Milk</p>
                <h4><b>Amul Gold Full Cream Fresh Milk</b></h4>
                <h6>⏱8 MINS</h6>
                <h6 style="color: green;">View all by Amul▸</h6>
                <hr>
                <h5>Select unit</h5>
                <div class="box">
                    <div class="box1">
                        <a href="Amul.php"><p style="margin: 11px;">500 ml <br>
                            MRP <b style="color: black;">₹34</b></p></a>
                    </div>
                    <div class="box1">
                        <a href="curd.php"><p style="margin: 11px;"> 1 l <br>
                            MRP <b style="color: black;">₹68</b></p></a>
                    </div>
                </div>
                <p>(Inclusive of all taxes)</p>
                <button>ADD</button>
                <h5 style="color: black;"><b>Why shop from blinkit?</b></h5>
                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/10_minute_delivery.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Best_Prices_Offers.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Wide_Assortment.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>






    </div>

    <script>
          function change_image(image_url){
        let parent = document.querySelector("#get_src").src = image_url;
      //  parent.src = image_url;
     //   console.log(parent);
        // let x = 500;
        // x + 600 = 1100;
    }
    </script>





    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
        integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>



</body>

</html>