<?php
session_start();
include 'config.php'; // Database connection

$submit = $_POST['submit'] ?? '';
$create_at = date('Y-m-d H:i:s');
$update_at = date('Y-m-d H:i:s');
$session_id = session_id();

switch ($submit) {
    case 'place_order':
        if (!isset($_POST['user_id'])) {
            die('User ID is missing.');
        }

        $user_id = intval($_POST['user_id']);
        $name = mysqli_real_escape_string($db, $_POST['name']);
        $number = mysqli_real_escape_string($db, $_POST['number']);
        $flat_no = mysqli_real_escape_string($db, $_POST['flat_no']);
        $floor = mysqli_real_escape_string($db, $_POST['floor']);
        $area = mysqli_real_escape_string($db, $_POST['area']);
        $landmark = mysqli_real_escape_string($db, $_POST['landmark']);
        $address = mysqli_real_escape_string($db, $_POST['address']);

        // Construct a full address (optional)
        $address = "$flat_no, $floor, $area, $landmark";

        // Update user table
        $sql = "UPDATE user SET 
                    name = '$name',
                    number = '$number',
                    flat_no = '$flat_no',
                    floor = '$floor',
                    area = '$area',
                    landmark = '$landmark',
                    address = '$address',
                    update_at = '$update_at'
                WHERE u_id = '$user_id'";

        if ($db->query($sql)) {
            header("Location: payment.php?msg=Order placed and details updated!");
        } else {
            echo "Error updating user details: " . $db->error;
        }
        exit();

    default:
        echo "No action found";
        break;
}
?>
