<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user info
$user_sql = "SELECT * FROM user WHERE u_id = ?";
$user_stmt = $db->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch orders (with items as JSON)
$order_sql = "SELECT * FROM orders WHERE u_id = ? ORDER BY id DESC";
$order_stmt = $db->prepare($order_sql);
$order_stmt->bind_param("i", $user_id);
$order_stmt->execute();
$order_result = $order_stmt->get_result();

$orders = [];
while ($order = $order_result->fetch_assoc()) {
    // Decode the JSON items field
    $order['items'] = json_decode($order['items'], true);
    $orders[] = $order;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>User Account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Funnel+Display:wght@300..800&family=SUSE:wght@100..800&display=swap"
        rel="stylesheet">
    <style>
        body {
            overflow-x: hidden;
        }

        .ads {
            border: 1px solid rgb(230, 230, 230);
            height: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0px -1px 6px -3px;
            padding-right: 0px;
        }

        .ads h5 {
            border-bottom: 1px solid rgb(230, 230, 230);
            height: 50px;
        }

        .text {
            /* border: 1px solid rgb(230, 230, 230); */
            height: 500px;
            text-align: left;
            width: 100%;
            border-bottom: 1px solid rgb(230, 230, 230);
            border-right: 1px solid rgb(230, 230, 230);
            border-top: 1px solid rgb(230, 230, 230);
            box-shadow: 2px -1px 6px -3px;
            padding-left: 0px;
        }

        .text h3 {
            margin-left: 0px;
            margin-top: 20px;
        }

        .text h5 {
            margin-top: 35px;
        }

        .text h6 {
            color: green;
            margin-top: 20px;

        }

        .time {
            display: flex;
            justify-content: space-around;
        }

        .set {
            margin-right: 116px;
        }

        .img-tx img {
            width: 60px;
            height: 50px;
        }

        .img-tx {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .img-tx button {
            background-color: green;
            color: white;
            border-radius: 10px;
        }

        .text-1 {
            display: flex;
            justify-content: space-between;
            margin-left: 20px;
        }

        .text-2 {
            display: flex;
            justify-content: space-between;
            margin-left: 20px;

        }

        .text-2 i {
            margin-left: 223px;
            margin-top: 6px;
        }

        .details {
            margin-top: 45px;
        }

        .cancel {
            margin-top: 30px;
        }

        .cancel h5 {
            margin-right: 196px;
        }

        .cancel p {
            color: #727272;
            text-align: left;
            margin-left: 10px;
        }

        .btu-btn button {
            width: 380px;
            height: 48px;
        }

        .btu-btn {
            margin-top: 70px;
            display: flex;
            margin-left: 20px;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            width: 250px;
            background-color: #f8f9fa;
            border-right: 1px solid #dee2e6;
            /* border: 1px solid #dee2e6; */
        }
        .sidebar h6{
            margin-left: 25px;
        }

        .tab-content {
            margin-left: 270px;
            padding: 20px;
        }

        .nav li {
            border: 1px solid #dee2e6;

        }
        .nav{
            padding-top: 28px;
        }
        .tab-pane h4{
            text-align: left;
        }
        .tab-pane span{
            color: #507E3E;
        }
        .on{
            display: flex;
            padding-top: 28px;
            margin-left: 27px;
        }
        .on i{
            margin-top: 4px;
            color: #F6CD45;
            padding-right: 14px;
        }
        .tab-pane p{
            margin-left: 60px;
        }
        .nav-item a{
            color: #727272;
        }
        .nav-item a:hover{
            color: rgb(54, 54, 54);
        }
        .nav-item i{
            margin-right: 20px;
        }
    </style>
</head>
<?php include 'header.php';?>

<body>

    
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="sidebar p-4">
                <h6>+917326028247</h6>
                <!-- <h6>My Addresses</h6> -->
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" id="my-address-link" data-toggle="tab" href="#my-addresses">
                            <i class="fa-solid fa-location-dot"></i>My Addresses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="my-orders-link" data-toggle="tab" href="#my-orders"><i class="fa-solid fa-clipboard-list"></i>My Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="e-gift-cards-link" data-toggle="tab" href="#e-gift-cards"><i class="fa-solid fa-gift"></i>E-Gift Cards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="account-privacy-link" data-toggle="tab" href="#account-privacy"><i class="fa-solid fa-lock"></i>Account
                            Privacy</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="logout-link" data-toggle="tab" href="#"><i class="fa-solid fa-user"></i></i>Logout</a>
                    </li>
                </ul>
            </div>
        
            <div class="tab-content">
                <div class="tab-pane fade show active" id="my-addresses">
                    <h4>My Addresses</h4>
                    <a href="">+ <span>Add new address</span></a> 
                    <!-- <button class="btn btn-primary">+ Add new address</button> -->
                     <div class="on">
                    <i class="fa-solid fa-house-chimney"></i>
                    <h5>Home</h5>
                </div>
                <p>
    <?= htmlspecialchars($user['address']) ?><br>
    <?= htmlspecialchars($user['flat_no']) ?><br>
    <?= htmlspecialchars($user['floor']) ?><br>
    <?= htmlspecialchars($user['area']) ?><br>
    <?= htmlspecialchars($user['landmark']) ?><br>
    India
</p>
                </div>
                <div class="tab-pane fade" id="my-orders">
                    <h4>My Orders</h4>
                    <?php if (empty($orders)): ?>
    <p>No orders available yet.</p>
<?php else: ?>
    <?php foreach ($orders as $order): ?>
        <div class="order-card p-3 mb-3 border rounded shadow-sm">
            <h6>Order #<?= htmlspecialchars($order['order_id']) ?> —
                <span class="badge bg-success"><?= ucfirst($order['sts']) ?></span>
            </h6>
            <p><strong>Ordered On:</strong> <?= date("d M Y, h:i A", strtotime($order['create_at'])) ?></p>
            <p><strong>Total:</strong> ₹<?= number_format($order['total_amount']) ?></p>

            <p><strong>Delivery Address:</strong><br>
                <?= htmlspecialchars($order['name']) ?><br>
                <?= htmlspecialchars($order['address']) ?><br>
                <?= htmlspecialchars($order['flat_no']) ?><br>
                <?= htmlspecialchars($order['floor']) ?><br>
                <?= htmlspecialchars($order['area']) ?><br>
                Phone: <?= htmlspecialchars($order['landmark']) ?>
            </p>

            <p><strong>Items:</strong><br>
            <?php
if (is_array($order['items'])) {
    $total_price = 0;

    foreach ($order['items'] as $item) {
        $pname = htmlspecialchars($item['p_name'] ?? 'N/A');
        $qty = (int)($item['qty'] ?? 0);
        $price = (float)($item['price'] ?? 0);
        $line_total = $qty * $price;
        $total_price += $line_total;

        echo "$pname — Qty: $qty × ₹" . number_format($price) . "<br>";
    }

    echo "<strong>Total: ₹" . number_format($total_price) . "</strong>";
} else {
    echo "No items available.";
}
?>

            </p>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
                </div>
                <div class="tab-pane fade" id="e-gift-cards">
                    <h4>E-Gift Cards</h4>
                    <p>Your e-gift cards will appear here.</p>
                </div>
                <div class="tab-pane fade" id="account-privacy">
                    <h4>Account Privacy</h4>
                    <p>Your account privacy settings will appear here.</p>
                </div>
                <div class="tab-pane fade" id="logout">
                    <a href="logout.php"><h4>Logout</h4></a>
                    <p>Your logout settings will appear here.</p>
                </div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    
</body>

</html>