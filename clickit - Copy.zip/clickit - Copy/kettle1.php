<?php include 'config.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Funnel+Display:wght@300..800&family=SUSE:wght@100..800&display=swap"
        rel="stylesheet">


    <style>
        .logo img {
            width: 147px;
            height: 48px;
        }

        .image img {
            width: 83%;
            height: 100%;
            margin-left: 140px;
        }

        .image1 {
            width: 70%;
            margin-left: 165px;
        }

        .image1 img {
            width: 30%;


        }

        .mycontainer1 {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgb(230, 230, 230);
            width: 100%;
            margin-top: 10px;
            /* position: fixed; */
            /* border: 1px solid grey; */
        }

        input {
            width: 600px;
            height: 45px;
            border-radius: 10px;
            /* border: 1px solid grey; */
            border: 1px solid rgb(188, 184, 184);
        }


        .text2 a {
            text-decoration: none;
            color: rgb(22, 21, 21);

        }

        .btn button {
            background-color: green;
            color: white;
            width: 100px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .cal-md-6 {
            width: 600px;
            height: 600px;
            margin-left: 55px;
        }

        .cal-md-6 img {
            width: 100%;
            height: 90%;
        }

        .row {
            display: flex;
            justify-content: space-around;
            width: 100%;
            height: 100%;
            /* margin-left: 20px; */
            /* margin-left: 40px; */
            /* border: 1px solid grey; */
        }

        h3 {
            color: green;
        }

        .box1 {
            width: 103px;
            height: 73px;
            border: 2px solid green;
            border-radius: 10px;
            text-align: center;
            margin-top: -7px;
            margin-right: 10px;
        }

        .box {
            width: 43%;
            display: flex;
            justify-content: space-between;
            margin: 2px;
        }

        button {
            margin-bottom: 5px;
            color: green;
            background-color: green;
            background: transparent;
            border-radius: 5px;
            width: 60px;
            height: 30px;
            border: 1px solid green;
        }

        hr {
            border: 1px solid rgb(186, 180, 180);
        }

        .service-1 {
            display: flex;
            justify-content: space-between;
        }

        .srv-1 img {
            width: 79px;
            height: 62px;
        }

        .srv-2 {
            margin-left: 20px;
        }

        /* h5 {
            text-decoration: none;
            color: rgb(12, 131, 31);
            font-size: 18px;
            line-height: 24px;
            font-family: Okra-Medium;
        } */

        footer {
            width: 90%;
            display: flex;
            justify-content: space-between;
            margin-top: 60px;
            font-size: 15px;
            color: rgb(0, 0, 0);
            height: 40vh;
            margin-left: 42px;
        }

        .tx {
            display: flex;
            justify-content: space-between;
        }



        .container-2 {
            text-align: center;
            height: 51px;
            /* position: fixed; */
        }

        .sidebar a {
            display: flex;
            text-decoration: none;
            color: black;
            border: 1px solid rgb(211, 206, 206);
            font-size: 15px;
            height: 100%;
            text-align: center;
        }

        .sidebar a img {
            width: 50px;
            height: 50px;
            margin-top: 10px;
        }

        .sidebar a:hover {
            background-color: rgb(140, 212, 140);
            color: white;
        }

        a {
            text-align: center;
            text-decoration: none;
            height: 75px;
        }

        .container-fluid {
            width: 93%;
            margin-left: 65px;
        }

        .heading {
            display: flex;
            justify-content: space-between;
        }

        .list-group li:hover {
            background-color: rgb(222, 218, 218);
            color: green;
        }

        .col-md-5 {
            display: flex;
            gap: 5rem;
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        /* .row {
            margin-top: 20px;
        } */

        .col-md-4 {
            display: flex;
            gap: 2rem;
        }

        .h6 {
            font-family: "Palanquin Dark", sans-serif;
        }

        b {
            font-family: "Parkinsans", sans-serif;
            font-weight: 900px;
            font-size: 18px;
            /* font-family: "Kanit", sans-serif;
            font-family: "Kanit", sans-serif;
            font-weight: 900; */
        }
        .head {
            margin-top: 80px;
            margin-left: 42px;
            margin-bottom: -54px;

        }
        .download img{
        width: 254px;
       }
       .side-n{
        width: 290px;
       }
    </style>
</head>
    <?php include 'header.php';?>
<body  style="margin: 0; padding: 0; overflow-x: hidden;">
   


    <div class="container-2" style="border-bottom: 1px solid rgb(230, 230, 230); box-shadow: 0px 7px 7px -7px;;">
        <nav class="navbar navbar-expand-lg bg-body-tertiary" style="margin-left: 250px;height: 47px; ">
            <div class="container-fluid" style="margin-top: 30px;">
                <!-- <a class="navbar-brand" href="Productonline.html">Vehetables & Fruits</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button> -->
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Vehetables & Fruits</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Dairy & Breakfast</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Munchies</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Cold Drinks & Juices</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Tea, Coffee & Health Drinks</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Productonline.php">Backery & Biscuits</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                More
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Sweet Tooth</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Atta, Rice & dal</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Dry Fruits, Masala & Oil</a>
                                </li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Sauces & Spreads</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Chicken, Meat & Fish</a>
                                </li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Paan Corner</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Organic & Premium</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="Productonline.php" style="height: 25px;">Baby Care</a></li>
                                <hr>
                                <li><a class="dropdown-item" href="kettle1.php" style="height: 25px;">Pharma & Wellness</a></li>
                                <hr>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
    </div>

    <div class="container-fluid">
        <div class="row" style="width: 85%; margin-left: 90px; margin-top: 27px;">
            <div class="col-md-4" style="    width: 358px; margin-top: 38px; margin-left: 41px;">
                <div class="sidebar">
                    <div class="side-n">
                    <a class="active" href="Productonline.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1323_1692947258191.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                    <a class="active" href="Productonline.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1102_1649432926740.png"
                            class="img-fluid" alt=""><h6>Soft Drinks</h6></a>
                    <a class="active" href="Productonline.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/955_1643385414974.png"
                            class="img-fluid" alt=""><h6>Fruit Juices</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1108_1684311412858.png"
                            class="img-fluid" alt=""><h6>Mango Drinks</h6></a>
                    <a class="active" href="Productonline.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1318_1684311395298.png"
                            class="img-fluid" alt=""><h6>Pure Juices</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/109_1677842362578.png"
                            class="img-fluid" alt=""><h6>Con</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1109_1643445639946.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/91_1684226377332.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1594_1680180957343.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px; "><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1594_1680180957343.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                    <a class="active" href="warning.php" style=" height: 75px;"><img
                            src="https://cdn.grofers.com/app/images/category/cms_images/icon/1594_1680180957343.png"
                            class="img-fluid" alt=""><h6>Beverages gift packs</h6></a>
                </div>
            </div>
            </div>

            <div class="col-md-8" style="margin-left: -93px; ">
                <!-- <section> -->

                <div class="heading">
                    <h4 style="margin-left: 80px; color: black;">Buy cough and cold online</h4>
                    <div class="btn-group">
                        <button class="btn text-success btn-sm" type="button" style="width: 145px;">
                            Price low to high
                        </button>
                        <button type="button" class="btn btn-sm text-success dropdown-toggle dropdown-toggle-split"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="visually-hidden">Toggle Dropdown</span>
                        </button>
                        <ul class="dropdown-menu">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    <input class="form-check-input me-1" type="checkbox" value="" id="firstCheckbox">
                                    <label class="form-check-label" for="firstCheckbox">Relevance</label>
                                </li>
                                <li class="list-group-item">
                                    <input class="form-check-input me-1" type="checkbox" value="" id="secondCheckbox">
                                    <label class="form-check-label" for="secondCheckbox">Price(low to high)</label>
                                </li>
                                <li class="list-group-item">
                                    <input class="form-check-input me-1" type="checkbox" value="" id="thirdCheckbox">
                                    <label class="form-check-label" for="thirdCheckbox">Price(high to low)</label>
                                </li>
                                <li class="list-group-item">
                                    <input class="form-check-input me-1" type="checkbox" value="" id="thirdCheckbox">
                                    <label class="form-check-label" for="thirdCheckbox">Discount</label>
                                </li>
                                <li class="list-group-item">
                                    <input class="form-check-input me-1" type="checkbox" value="" id="thirdCheckbox">
                                    <label class="form-check-label" for="thirdCheckbox">Name(a to z)</label>
                                </li>
                            </ul>
                        </ul>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="owl-carousel owl-theme">
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBvaLomPxpXoXTZtNi0sWuHrANMWVp7Q2MfA&s"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://www.jiomart.com/images/product/original/493634724/saffola-munchiez-ragi-chips-takatak-tomato-70-g-packet-product-images-o493634724-p603039950-0-202405281531.jpg?im=Resize=(1000,1000)"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://5.imimg.com/data5/ZH/TB/AB/SELLER-77460638/lays-potato-chips.png"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://5.imimg.com/data5/NT/US/IY/SELLER-67010193/soda-water-500x500.jpg"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://5.imimg.com/data5/SELLER/Default/2023/5/312217465/KP/NY/TT/113751815/pepsi-drinks.webp"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="owl-carousel owl-theme">
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://img.freepik.com/premium-vector/chocolate-ice-cream-bar-package-uses-white-background_317810-1524.jpg"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://atlas-content-cdn.pixelsquid.com/assets_v2/289/2891355456775657363/jpeg-600/G03.jpg?modifiedAt=1"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://5.imimg.com/data5/LR/XG/MY-44085689/milk-chocolate.jpg"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://images.jdmagicbox.com/quickquotes/images_main/cadbury-dairy-milk-chocolate-packaging-type-packet-2217353802-c0tnglmg.jpg"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card item">
                                <div class="card-body">
                                    <a class="active" href="Amul.php"><img
                                            src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142"
                                            alt="" class="img-fluid"></a>
                                </div>
                                <div class="card-footer">
                                    <h6>⏱8 MIN</h6>
                                    <!-- <br> -->
                                    <h6>Amul Gold Full Cream <br> Fresh Milk</h6>
                                    <!-- <br> -->
                                    <p>500ml</p>
                                    <!-- <br> -->
                                    <div class="pbtn">
                                        <h6>₹34</h6>
                                        <button>ADD</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>



                <!-- </section> -->
            </div>
        </div>

    </div>



    <?php include 'footer.php'; ?>






    <!-- <script>
        function change_image(image_url) {
            let parent = document.querySelector("#get_src").src = image_url;
        }
    </script> -->



    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
        integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>



    <script>
        $('.owl-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 5
                }
            }
        })
    </script>


</body>

</html>