<?php
session_start();
include "config.php"; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    
    // Check if any field is empty
    if (empty($name) || empty($email) || empty($mobile) || empty($password)) {
        $_SESSION['error'] = "All fields are required!";
        header("Location: register.php");
        exit();
    }

    // Check if email already exists
    $checkQuery = "SELECT u_id FROM `user` WHERE `email` = '$email'";
    $checkResult = mysqli_query($db, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        $_SESSION['error'] = "This email is already registered!";
        header("Location: register.php");
        exit();
    }

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert user data into the database
    $query = "INSERT INTO `user` (`name`, `email`, `number`, `password`, `create_at`) 
              VALUES ('$name', '$email', '$mobile', '$hashedPassword', NOW())";

    if (mysqli_query($db, $query)) {
        $_SESSION['success'] = "Registration successful! You can now login.";
        header("Location: login.php"); // Redirect to login page
        exit();
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again.";
        header("Location: register.php");
        exit();
    }
} else {
    $_SESSION['error'] = "Invalid Request!";
    header("Location: register.php");
    exit();
}
?>
