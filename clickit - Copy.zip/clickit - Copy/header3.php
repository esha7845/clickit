<?php
                    if (isset($_SESSION['error'])) {
                        echo "<div class='alert alert-danger'>" . $_SESSION['error'] . "</div>";
                        unset($_SESSION['error']);
                    }
                    ?>
                    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Funnel+Display:wght@300..800&family=SUSE:wght@100..800&display=swap"
        rel="stylesheet">
    <style>
            body{
                overflow-x: hidden;
            }
            .time {
            display: flex;
            justify-content: space-around;
        }

        .set {
            margin-right: 116px;
        }

        .img-tx img {
            width: 60px;
            height: 50px;
        }

        .img-tx {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .img-tx button {
            background-color: green;
            color: white;
            border-radius: 10px;
        }

        .text-1 {
            display: flex;
            justify-content: space-between;
            margin-left: 20px;
        }

        .text-2 {
            display: flex;
            justify-content: space-between;
            margin-left: 20px;

        }
        .text-2 i{
            margin-left: 223px;
            margin-top: 6px;
        }

        .details {
            margin-top: 45px;
        }

        .cancel {
            margin-top: 30px;
        }

        .cancel h5 {
            margin-right: 196px;
        }

        .cancel p {
            color: #727272;
            text-align: left;
            margin-left: 10px;
        }

        .btu-btn button {
            width: 380px;
            height: 48px;
        }

        .btu-btn {
            margin-top: 70px;
            display: flex;
            margin-left: 20px;
        }
        .set-get{
            width: 36px;
                height: 33px;
        }
        .checkbox{
            display: flex;
            justify-content: space-between;
            width: 356px;
        }
        .checkbox input{
            width: 14px;
            margin-top: 10px

        }
        .text-2 span{
            margin-left: 10px;
        }
        .btu-btn button{
            width: 310px;
            background-color: #0C831F;
            color: white;
        }
        .offcanvas{
            width: 550px;
        }
        .remv {
            margin-left: 71px;
        }
    </style>
</head>
<body>
    <div class="row" style="border-bottom: 1px solid rgb(230, 230, 230);">


        <div class=" col-md-2 logo" style=" margin-right: -55px;">
            <a class="active" href="index.php">
                <img src="https://www.thehealthfactory.in/cdn/shop/files/BLINKIT_876a5ffa-38b0-4f7b-8c54-0c3b56d69c38.png?crop=center&height=2048&v=1697781264&width=2048"
                    alt="" class="img-fluid">
            </a>
        </div>

        <div class="col-md-2  " style="margin-right: -35px;">
            <h6 style="text-align: center;"><b style="font-weight: bolder;">Deliver in 8 minutes</b></h6>
            <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h6>Delhi, India ▾</h6>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content" style="margin-top: 93px; margin-left: -400px;">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel" style="text-align: left;">Change
                                location</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <button
                                style="width: 136px; border-radius: 8px; height: 50px; background-color: green; color: white; border: 2px solid rgb(230, 230, 230);">Detect
                                my location</button>
                            <button
                                style="width: 243px; border-radius: 10px; height: 45px; margin-left: 10px; border: 2px solid rgb(230, 230, 230);">
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class=" col-md-6 form">
            <a href="search.php">
                <nav class="navbar bg-transparent text-success" style="width: 824px;">
                    <form class="container-fluid" style="width: 100%; text-decoration: none; margin-left: 66px;">
                        <div class="input-group">
                            <span class="input-group-text" id="basic-addon1"><i
                                    class="fa-solid fa-magnifying-glass"></i></span>
                            <input type="text" class="form-control" placeholder="search" aria-label="Username"
                                aria-describedby="basic-addon1">
                        </div>
                    </form>
                </nav>
            </a>
        </div>

        <div class=" col-md-1" style="    text-align: center; margin-top: 10px; margin-left: 76px;">
        <?php if (isset($_SESSION['user_id'])): ?>
        <!-- Account Dropdown -->
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="accountDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo htmlspecialchars($_SESSION['user_name']); ?>
            </button>
            <ul class="dropdown-menu" aria-labelledby="accountDropdown">
                <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="managelogin.php?action=logout">Logout</a></li>
            </ul>
        </div>
    <?php else: ?>
        <!-- Login Button -->
        <button type="button" class="btn text-dark" data-bs-toggle="modal" data-bs-target="#Login">
            Login
        </button>
    <?php endif; ?>

            <div class="modal fade" style="margin-top: 8px;" id="Login" tabindex="-1" aria-labelledby="loginModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="border-radius: 25px;">
                        <!-- <div class="modal-header">
                            <h1 class="modal-title fs-6" id="loginModalLabel"><b>Login</b></h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div> -->
                        <div class="modal-body">
                            <img src="https://cdn.grofers.com/layout-engine/2023-11/app_logo.svg" alt=""
                                style="width: 115px; height: 70px;">
                            <div class="text">

                                <h3 style="margin-left: 28px; color: black;">India's last minute app</h3>
                                <p>Log in or Sign up</p>
                            </div>
                            
                            <form action="managelogin.php" method="POST">
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
                        </div>
                        <button type="submit" name="submit" class="btn btn-dark">Continue</button>
                    </form>
                            <p>your email is not found, please <a href="register.php"><span>sign up</span></a></p>
                        </div>
                        <!-- <div class="modal-footer">
                            <button type="button" class="btn text-dark" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn text-success">Continue</button>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

        <?php
$totalPrice = 0; // Initialize total price

$cartItems = $db->query("
    SELECT cart.*, product.image 
    FROM cart 
    JOIN product ON cart.product_id = product.p_id
");
?>

<div class="col-md-1" style="margin-top: 4px;">
    <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight" style="width: 104px; height: 48px;">
        <i class="fa-solid fa-cart-shopping"></i> My Cart
    </button>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasRightLabel"><i class="fa-solid fa-cart-shopping"></i> My Cart</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <hr>
        <div class="offcanvas-body">
            <div class="time">
                <i class="fa-solid fa-stopwatch"></i>
                <div class="set">
                    <h6>Delivery in 9 minutes</h6>
                    <p>Shipment of <?= $cartItems->num_rows ?> items</p>
                </div>
            </div>

            <?php if ($cartItems->num_rows > 0) { ?>
                <form id="cart-form" action="admin/action/add_to_cart.php" method="post">
                    <div id="cart-items">
                        <?php while ($item = $cartItems->fetch_assoc()) { 
                            $totalPrice += $item['price'] * $item['quantity'];
                        ?>
                            <div class="img-tx">
                                <div class="checkbox">
                                <input type="checkbox" name="selected_products[]" value="<?= $item['product_id']; ?>" onclick="toggleRemoveButton()">
                                
                                <img src="<?= !empty($item['image']) ? 'uploads/' . htmlspecialchars($item['image']) : 'uploads/default.jpg'; ?>" 
                                     alt="<?= htmlspecialchars($item['product_name']); ?>" class="img-fluid" width="50">

                                <div class="te-xt" >
                                    <?= htmlspecialchars($item['product_name']); ?><br>
                                    <span class="unit">1 unit</span><br>
                                    ₹<span class="price"><?= $item['price']; ?></span>
                                </div>

                                <div class="remv">
                                    <button type="button" class="set-get" onclick="updateQuantity(<?= $item['product_id']; ?>, 'decrease')">-</button>
                                    <span id="quantity-<?= $item['product_id']; ?>"><?= $item['quantity']; ?></span>
                                    <button type="button" class="set-get" onclick="updateQuantity(<?= $item['product_id']; ?>, 'increase')">+</button>
                                    <a href="admin/action/add_to_cart.php?submit=remove_from_cart&product_id=<?= $item['product_id']; ?>" 
                                       onclick="return confirm('Are you sure you want to remove this item?')">Remove</a>
                                </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="btu-btn" id="remove-selected-container" style="display: none;">
                        <button type="button" onclick="removeSelectedItems()">Remove Selected</button>
                    </div>
                </form>

                <div class="details">
                    <div class="text-1">
                        <h5>Bill details</h5>
                    </div>
                    <div class="text-2">
                        <h6>Items total</h6>
                        
                       <span id="items-total"><span> ₹</span><?= $totalPrice; ?></span>
                    </div>
                    <div class="text-2">
                        <h6>Delivery charge</h6>
                        <span id="delivery-charge">₹25</span>
                    </div>
                    <div class="text-2">
                        <h6>Handling charge</h6>
                       <span id="handling-charge"> ₹5</span>
                    </div>
                    <div class="text-1">
                        <h6>Grand total</h6>
                        <b>₹<span id="grand-total"><?= $totalPrice + 25 + 5; ?></span></b>
                    </div>
                </div>

                <div class="btu-btn">
                    <button onclick="checkout()">Proceed to Checkout</button>
                </div>
            <?php } else { ?>
                <p>Your cart is empty.</p>
            <?php } ?>
        </div>
    </div>
</div>

<script>
function updateQuantity(productId, action) {
    let quantitySpan = document.getElementById("quantity-" + productId);
    let priceSpan = document.querySelector(".price");
    let itemsTotalSpan = document.getElementById("items-total");
    let grandTotalSpan = document.getElementById("grand-total");

    let price = parseFloat(priceSpan.innerText);
    let quantity = parseInt(quantitySpan.innerText);

    if (action === 'increase') {
        quantity += 1;
    } else if (action === 'decrease' && quantity > 1) {
        quantity -= 1;
    }

    quantitySpan.innerText = quantity;
    
    // Update total amounts
    let itemsTotal = 0;
    document.querySelectorAll(".img-tx").forEach(function (item) {
        let itemPrice = parseFloat(item.querySelector(".price").innerText);
        let itemQuantity = parseInt(item.querySelector("span[id^='quantity-']").innerText);
        itemsTotal += itemPrice * itemQuantity;
    });

    itemsTotalSpan.innerText = itemsTotal;
    grandTotalSpan.innerText = itemsTotal + 25 + 5;
}

function removeSelectedItems() {
    let form = document.getElementById('cart-form');
    let selected = document.querySelectorAll('input[name="selected_products[]"]:checked');

    if (selected.length === 0) {
        alert("Please select at least one item to remove.");
        return;
    }

    if (confirm("Are you sure you want to remove selected items?")) {
        form.action = "admin/action/add_to_cart.php?submit=remove_selected";
        form.submit();
    }
}

// Show or hide "Remove Selected" button based on checkbox selection
function toggleRemoveButton() {
    let selected = document.querySelectorAll('input[name="selected_products[]"]:checked').length;
    let removeButtonContainer = document.getElementById('remove-selected-container');
    removeButtonContainer.style.display = selected > 0 ? "block" : "none";
}

function checkout() {
    alert("Proceeding to checkout...");
}
</script>



        </div>
    </div>
</body>
</html>