<?php
session_start();
include "config.php"; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = $_POST['password'];

    // Check if fields are empty
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "All fields are required!";
        header("Location: login.php");
        exit();
    }

    // Check if the user exists in the database
    $query = "SELECT * FROM `user` WHERE `email` = '$email'";
    $result = mysqli_query($db, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Verify the password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['u_id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['success'] = "Login successful!";

            // Redirect to the homepage (index.php)
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error'] = "Invalid password!";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "No account found with this email!";
        header("Location: login.php");
        exit();
    }
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: login.php");
    exit();
}
?>
