<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"
        integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .navbar {
            background-color: #F8CB46;
            width: 100%;
            height: 53px;
            position: sticky;
        }

        .navbar img {
            width: 100px;
            height: 21px;
            margin-left: 20px;
            margin-bottom: 10px;
        }

        .navbar a {
            text-decoration: none;
            color: black;
        }

        .navbar li {
            list-style: none;
        }

        .navbar ul {
            display: flex;
            justify-content: space-between;
        }

        nav {
            width: 411px;
        }

        nav ul {
            margin-right: 30px;
        }

        i {
            margin-top: 7px;
        }

        .image-1 {
            height: 63vh;
            width: 100%;
            background-image: url("https://blinkit.com/careers/sites/default/files/2024-05/career-masthead-desktop.png");
            background-position: center;
            background-size: cover;
            padding-left: 5%;
            padding-right: 5%;
            box-sizing: border-box;
            position: relative;
            background-color: #F8CB46;
            /* position: sticky; */

        }


        footer {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-top: -7px;
            font-size: 15px;
            color: rgb(0, 0, 0);
            height: 40vh;
            margin-left: 26px;
        }

        .tx {
            display: flex;
            justify-content: space-between;
        }



        .container-2 {
            text-align: center;
        }

        .col-md-5 {
            display: flex;
            gap: 5rem;
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        .col-md-5 ul a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        .col-md-7 ul a {
            text-decoration: none;
            color: #727272;

        }

        .head {
            /* margin-top: 140px; */
            margin-top: 80px;
            margin-left: 42px;
            margin-bottom: -54px;
        }

        .col-md-4 {
            display: flex;
            gap: 2rem;
        }

        .download img {
            width: 254px;
        }
    </style>
</head>

<body>

<?php include 'header2.php'; ?>
   

    <div class="image-1">

    </div>
    <div class="text">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8" style="margin-top: 40px;">
                <h1>100x retail in 5 years</h1>
                <br>
                <p>Imagine needing something when you are at home and getting it before you have tied your shoelaces to
                    step out. We are revolutionizing e-commerce by making the stuff most important to you, available to
                    you in a blink of your eye.
                </p>

                <p>Imagine needing something when you are at home and getting it before you have tied your shoelaces to
                    step out. We are revolutionizing e-commerce by making the stuff most important to you, available to
                    you in a blink of your eye.
                </p>

                <p>Imagine needing something when you are at home and getting it before you have tied your shoelaces to
                    step out. We are revolutionizing e-commerce by making the stuff most important to you, available to
                    you in a blink of your eye.
                </p>

                <p>Imagine needing something when you are at home and getting it before you have tied your shoelaces to
                    step out. We are revolutionizing e-commerce by making the stuff most important to you, available to
                    you in a blink of your eye.
                </p>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    </div>



    <div class="text-wrapper">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8" style="margin-top: 87px;">
                <h6>#1 instant delivery service in India</h6>
                <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                    fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                    accessories, electronics, baby care products and much more. We get it delivered at your
                    doorstep in the fastest and the safest way possible.</p>

                <h6>#1 instant delivery service in India</h6>
                <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                    fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                    accessories, electronics, baby care products and much more. We get it delivered at your
                    doorstep in the fastest and the safest way possible.</p>

                <h6>#1 instant delivery service in India</h6>
                <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                    fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                    accessories, electronics, baby care products and much more. We get it delivered at your
                    doorstep in the fastest and the safest way possible.</p>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>

    <?php include 'footer.php'; ?>












        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>
</body>

</html>