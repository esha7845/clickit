<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"
        integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        .navbar {
            background-color: #F8CB46;
            width: 100%;
            height: 53px;
            position: sticky;
        }

        .navbar img {
            width: 100px;
            height: 21px;
            margin-left: 20px;
            margin-bottom: 10px;
        }

        .navbar a {
            text-decoration: none;
            color: black;
        }

        .navbar li {
            list-style: none;
        }

        .navbar ul {
            display: flex;
            justify-content: space-between;
        }

        nav {
            width: 411px;
        }

        nav ul {
            margin-right: 30px;
        }

        i {
            margin-top: 7px;
        }

        .image-1 {
            height: 80vh;
            width: 100%;
            background-image: url("https://blinkit.com/careers/sites/default/files/2021-12/contact-masthead.png");
            background-position: center;
            background-size: cover;
            padding-left: 5%;
            padding-right: 5%;
            box-sizing: border-box;
            position: relative;
            /* position: sticky; */

        }

        .box {
            width: 500px;
            height: 500px;
            background-color: white;
            margin-top: 60px;
            margin-left: 70px;
        }

        .btn button {
            text-align: center;
            margin-left: 196px;
            margin-top: 145px;
            border-radius: 10px;
            margin-right: 40px;
            width: 344px;
            height: 47px;
            background-color: black;
            color: white;
        }

        footer {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-top: -7px;
            font-size: 15px;
            color: rgb(0, 0, 0);
            height: 40vh;
            margin-left: 26px;
        }

        .tx {
            display: flex;
            justify-content: space-between;
        }



        .container-2 {
            text-align: center;
        }

        .col-md-5 {
            display: flex;
            gap: 5rem;
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        .col-md-5 ul a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        .col-md-7 ul a {
            text-decoration: none;
            color: #727272;

        }

        .head {
            /* margin-top: 140px; */
            margin-top: 119px;
            margin-left: 42px;
            margin-bottom: -54px;
        }

        .col-md-4 {
            display: flex;
            gap: 2rem;
        }

        .download img {
            width: 254px;
        }

        .wrap {
            text-align: center;
            margin-top: 23px;
        }
    </style>
</head>

<body style="overflow-x: hidden;">
<?php include 'header2.php'; ?>
   

    <div class="image-1">
        <div class="row">
            <div class="col-md-6">
                <h1 style="margin-top: 84px; margin-left: 135px;">We would ❤️️ to <br> hear from you</h1>
            </div>
            <div class="col-md-6">
                <div class="box">
                    <div class="sign">
                        <form>
                            <div class="form-group" style="width: 417px; height: 63px; margin-left: 40px; ">
                                <label for="exampleFormControlSelect1"></label>
                                <select class="form-control" id="exampleFormControlSelect1">
                                    <option>how can we help you ?</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                </select>
                            </div>

                            <div class="form-group" style="width: 417px; height: 63px; margin-left: 40px;">
                                <label for="exampleFormControlInput1"></label>
                                <input type="email" class="form-control" id="exampleFormControlInput1"
                                    placeholder="email*">
                            </div>

                            <div class="form-group" style="width: 417px; height: 63px; margin-left: 40px;">
                                <label for="exampleFormControlInput1"></label>
                                <input type="email" class="form-control" id="exampleFormControlInput1"
                                    placeholder="phone*">
                            </div>

                            <div class="form-group" style="width: 417px; height: 63px; margin-left: 40px;">
                                <label for="exampleFormControlTextarea1"></label>
                                <p>10 character(s) remaining</p>
                                <textarea class="form-control" id="exampleFormControlTextarea1"
                                    placeholder="enter the details" rows="5"></textarea>
                            </div>

                            <!-- Submit button centered -->
                            <div class="form-group" style="text-align: center; margin-left: 40px;">
                                <button type="submit" class="btn btn-primary"
                                    style="width: 417px; margin-top: 148px; margin-right: 36px; background-color: black; color: white;">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="text-wrapper">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8" style="margin-top: 87px;">
                    <h6>#1 instant delivery service in India</h6>
                    <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                        fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                        accessories, electronics, baby care products and much more. We get it delivered at your
                        doorstep in the fastest and the safest way possible.</p>

                    <h6>#1 instant delivery service in India</h6>
                    <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                        fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                        accessories, electronics, baby care products and much more. We get it delivered at your
                        doorstep in the fastest and the safest way possible.</p>

                    <h6>#1 instant delivery service in India</h6>
                    <p>Shop on the go and get anything delivered in minutes. Buy everything from groceries to fresh
                        fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles &
                        accessories, electronics, baby care products and much more. We get it delivered at your
                        doorstep in the fastest and the safest way possible.</p>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>

        <?php include 'footer.php'; ?>


    </div>













    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>