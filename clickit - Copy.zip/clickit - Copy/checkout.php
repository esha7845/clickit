<?php include 'header.php';
   if (empty($_SESSION['u_id'])) {
      echo '<script>window.location.replace("register-login.php")</script>';
      exit();
   }



?>
<?php include 'navbar.php';?>


<div class="container">
	<div class="card mt-3 mb-3">
      <div class="card-body">
                  <form action="backend/action/checkout_mng.php" >

<div class="row">
               <div class="col-6">
                  <!-- left side start -->

                     
         <?php
            if(!empty($_REQUEST['ch_id']))
            {
               $ch_id = $_REQUEST['ch_id'];
            } else{
                  $ch_id ='';
            }
            $edit = $db->query("SELECT * FROM `checkout` WHERE ch_id = '$ch_id'");
            $edit_value = $edit->fetch_object();
            ?>




            <?php    
         if (empty($_SESSION['u_id'])) {
           $session_id = session_id();
           $data = $db->query("SELECT * FROM `cart` WHERE  session_id = '$session_id' AND sts = 0");
         }else{
           $u_id = $_SESSION['u_id'];
           $data = $db->query("SELECT * FROM `cart` WHERE u_id = '$u_id' AND sts = 0");
         }
         if ($data->num_rows  ==  0) {
          
         
         ?>
            
        
      <!-- when cart is empty -->
      <div class="cartimg">
         <img src="./image/empemptycart.webp">
      </div>
      <div class="h5 ct">
         <b>You don't have any items in your<br> cart</b>
      </div>
      <p class="ct">Your favourite items are just a click away</p>
     <a href="clickitindex.php" class="btn btn-success  cbutton"> Start shoping</a>
      <?php } else { 
         $grand = 0;
         while($value = $data->fetch_object()){
            $p_id=$value->p_id;
            $data1=$db->query("SELECT * FROM `product` WHERE p_id='$p_id'");
            $value1=$data1->fetch_object();
         global $totals;
         
         
         $totals += $value->p_price * $value->qty;
          $grand += $totals;
         ?> 
      <!-- cart empty end hear -->
      <div class="card loadcart wpic allproduct">
         <div class="card-body">
      <input type="hidden" name="cart_id[]" value="<?=$value->cart_id;?>">


         <!-- <div class="fillcard">
            <img class="timerimg" src="./image/timer.webp">
            <p><b>  Delivery in 9 minutes </b>  <br>
               <span class="shipment">    Shipment of 1 item  </span> 
            </p>
            </div> -->
         <div class="cartpro allproduct">
            <img class=""src="backend/uploads/<?=$value->p_img?>" width="100px">
            <p class="hgh"> <b> <?=$value->p_name?></b><br>
               unit- <?=$value1->unit?>
               <a href="action/cart_manage.php?submit=delete_cart&cart_id=<?=$value->cart_id;?>"></a>
               <br>

               Price- <i class="fa fa-inr price"> <?=$value->p_price;?></i>

               <b class="dlt">Qty-<?=$value->qty;?></b>
              
               <i class=" dlt fa-solid fa-trash fa-lg trash"></i>

            </p>
            <!-- <button class="btn   cartboxadd"> ADD  </button> -->
         </div>
      </div>
      </div>
      <?php } ?>
      <div class="card bill allproduct">
         <div class="card-body">
         <p class="bd"> <b>Bill Details</b>  </p>
         <div class="mrp">
            <p class="mr">MRP</p>
            <p>  <i class="fa fa-inr price"><?=$grand;?></i></p>
         </div>
         <div class="mrp">
            <p class="mr">Delivery Charges</p>
            <p>  <i class="fa fa-inr price">Free Delivery</i></p>
         </div>
         <p class="sf">Shop for ₹54 more, to save ₹25 on delivery charge</p>
         <div class="mrp">
            <p class="mr"><b>Grand Total</b>    </p>
            <p>  <i class="fa fa-inr price"><?=$grand;?></i></p>
         </div>


         <div class="form-check form-check-inline">
            <p><b> Payment mode</b></p>
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1"><b>Cash On Delivery</b></label>
</div>





         <p class="cao">Coupons are only applicable on the Blinkit app</p>
      </div>
      </div>
      <div class="card cancel">
         <div class="card-body">
         <p class=""><b>Cancellation Policy</b></p>
         <p class="">Orders cannot be cancelled once packed for delivery. In case of unexpected delays, a refund will be provided, if applicable.</p>
      </div>
      </div>
      
   
   <?php }   ?>
                  
                  <!-- left side end -->
               </div>
                  
               <div class="col-6">
                  <?php
            if(!empty($_REQUEST['ch_id']))
            {
               $ch_id = $_REQUEST['ch_id'];
            } else{
                  $ch_id ='';
            }
            $edit = $db->query("SELECT * FROM `checkout` WHERE ch_id = '$ch_id'");
            $edit_value = $edit->fetch_object();
            ?>

                  <h6>Enter Complte Adress</h6>

                  <div class="input-group">
                        <input type="text" class="form-control fm-1" name="h_name" placeholder="flat / House no / Building name*"required value="<?php if (!empty($edit_value->h_name)) {
                        echo $edit_value->h_name; 
                     }?>" >
                     </div>
                     <div class="input-group">
                        <input type="text" class="form-control fm-1" name="floor" placeholder="Floor (optional)"required value="<?php if (!empty($edit_value->floor)) {
                        echo $edit_value->floor;
                     }?>" >
                     </div>
                     <div class="input-group">
                        <input type="text" class="form-control fm-1" name="land_mark" placeholder="Landmark (near by Location)"required value="<?php if (!empty($edit_value->land_mark)) {
                        echo $edit_value->land_mark;
                     }?>">
                     </div>
                     <div>
                        <p>Add Receiver Information</p>
                      <div class="input-group">

                        <input type="text" class="form-control fm-1" name="r_name"placeholder="Receivers Name *"required value="<?php if (!empty($edit_value->r_name)) {
                        echo $edit_value->r_name;
                     }?>" >
                     </div>
                     <div class="input-group">
                        <input type="number" class="form-control fm-1" name="r_no" placeholder="Receivers Phone No*"required value="<?php if (!empty($edit_value->r_no)) {
                        echo $edit_value->r_no;
                     }?>" >
                     </div>
                  </div>

                   

                     <button class="btn btn-success proceed" name="submit" value="submit_form" type="submit"  >Proceed-</button>
                     
                  </div>
               </div>
      </div>
           </div>
                                </form>

           </div>

<?php include 'footer.php';?>
