<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Palanquin+Dark:wght@400;500;600;700&family=Parkinsans:wght@300..800&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Funnel+Display:wght@300..800&family=SUSE:wght@100..800&display=swap"
        rel="stylesheet">

    
</head>

<body style="margin: 0; padding: 0; overflow-x: hidden;">
                    <?php include 'header.php';?>

    <div class="container-fluid" style="display: flex;">

        <div class="row">
            <div class="col-md-6">
                <img src="https://mcprod.spencers.in/media/catalog/product/1/2/1260586_1.jpg" id="get_src"
                    class="img-fluid">

                <div class="row mt-3" style="height: 70%;">
                    <div class="col-md-2">
                        <img src="https://mcprod.spencers.in/media/catalog/product/1/2/1260586_1.jpg" class="img-fluid"
                            onclick="change_image(this.src)">
                    </div>

                    <div class="col-md-2">
                        <img src="https://img.cdnx.in/372005/amul-gold-full-cream-fresh-milk-1718705295678_SKU-6523_0.jpg?width=600&format=webp"
                            onclick="change_image(this.src)" class="img-fluid">
                    </div>


                    <div class="col-md-2">
                        <img src="https://www.spencers.in/media/catalog/product/1/2/1260586_3.jpg"
                            onclick="change_image(this.src)" class="img-fluid">
                    </div>


                    <div class="col-md-2">
                        <img src="https://m.media-amazon.com/images/I/51xDwKRnT3L._AC_UF350,350_QL80_.jpg"
                            class="img-fluid" onclick="change_image(this.src)">
                    </div>

                    <div class="col-md-2">
                        <img src="https://img.thecdn.in/23327/1624109906447_SKU-0755_0.jpg?width=600" class="img-fluid"
                            onclick="change_image(this.src)">
                    </div>



                </div>

            </div>




            <div class="col-md-6" style="margin-top: 25px;">
                <p>Home / Milk / Amul Gold Full Cream Fresh Milk</p>
                <h4><b>Amul Gold Full Cream Fresh Milk</b></h4>
                <h6>⏱8 MINS</h6>
                <h6 style="color: green;">View all by Amul▸</h6>
                <hr>
                <h5>Select unit</h5>
                <div class="box">
                    <div class="box1">
                        <a href="Amul.html">
                            <p style="margin: 11px;">500 ml <br>
                                MRP <b style="color: black;">₹34</b></p>
                        </a>
                    </div>
                    <div class="box1">
                        <a href="curd.html">
                            <p style="margin: 11px;"> 1 l <br>
                                MRP <b style="color: black;">₹68</b></p>
                        </a>
                    </div>
                </div>
                <p>(Inclusive of all taxes)</p>
                <button>ADD</button>
                <h5 style="color: black;"><b>Why shop from blinkit?</b></h5>
                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/10_minute_delivery.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Best_Prices_Offers.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Wide_Assortment.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>
            </div>
        </div>
</div>
    


   





    <?php include 'footer.php'; ?>

    <script>
        function change_image(image_url) {
            let parent = document.querySelector("#get_src").src = image_url;
            //  parent.src = image_url;
            //   console.log(parent);
            // let x = 500;
            // x + 600 = 1100;
        }
    </script>





    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
        integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>



</body>

</html>