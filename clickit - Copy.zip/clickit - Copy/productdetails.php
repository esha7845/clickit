<?php
include 'config.php'; // Ensure your database connection is included

// Get the product ID from the URL
if (isset($_GET['p_id'])) {
    $p_id = intval($_GET['p_id']);

    // Fetch the product details
    $query = "SELECT p.*, c.c_name, s.sub_name FROM product p
              INNER JOIN category c ON p.c_id = c.c_id
              INNER JOIN subcategory s ON p.s_id = s.s_id
              WHERE p.p_id = ?";
    
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $p_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    // Fetch extra product images related to this product
    $extraImages = [];
    $extraproductQuery = "SELECT * FROM extraproduct WHERE p_id = ?";
    $stmt2 = $db->prepare($extraproductQuery);
    $stmt2->bind_param("i", $p_id);
    $stmt2->execute();
    $extraResult = $stmt2->get_result();

    while ($row = $extraResult->fetch_assoc()) {
        $extraImages[] = $row['file'];
    }
} else {
    echo "Product not found!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['p_name']); ?></title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">


</head>

<body style="margin: 0; padding: 0; overflow-x: hidden;">

    <?php include 'header.php'; ?>

    <div class="container-fluid " style="display: flex;">
        <div class="row">
            <div class="col-md-6">
                <img src="<?= !empty($product['image']) ? "uploads/" . htmlspecialchars($product['image']) : 'placeholder.jpg'; ?>" 
                    id="get_src" class="img-fluid">

                <div class="row mt-3" style="height: 70%;">
                    <div class="col-md-2">
                        <img src="<?= "uploads/" . htmlspecialchars($product['image']); ?>" class="img-fluid"
                            onclick="change_image(this.src)">
                    </div>

                    <?php foreach ($extraImages as $extra) { ?>
                        <div class="col-md-2">
                            <img src="<?= "uploads/" . htmlspecialchars($extra); ?>" class="img-fluid"
                                onclick="change_image(this.src)">
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="col-md-6" style="margin-top: 25px;">
                <p>Home / <?= htmlspecialchars($product['c_name']) ?> / <?= htmlspecialchars($product['p_name']) ?></p>
                <h4><b><?= htmlspecialchars($product['p_name']); ?></b></h4>
                <h6>⏱8 MINS</h6>
                <h6 style="color: green;">View all by <?= htmlspecialchars($product['c_name']); ?>▸</h6>
                <hr>

                <!-- Quantity & Price Update Section -->
                <h5>Quantity</h5>
                <div class="d-flex align-items-center">
                    <button class="btn btn-outline-secondary" onclick="changeQuantity(-1)">-</button>
                    <input type="text" id="quantity" value="1" class="form-control text-center mx-2" style="width: 50px;" readonly>
                    <button class="btn btn-outline-secondary" onclick="changeQuantity(1)">+</button>
                </div>

                <h5 class="mt-3">Price: ₹<span id="updatedPrice"><?= htmlspecialchars($product['price']); ?></span></h5>
                <p>(Inclusive of all taxes)</p>
                
                <button class="btn btn-success mt-2">ADD</button>
                <h5 style="color: black;"><b>Why shop from blinkit?</b></h5>
                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/10_minute_delivery.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Best_Prices_Offers.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>

                <div class="service-1">
                    <div class="srv-1">
                        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/web/blinkit-promises/Wide_Assortment.png"
                            alt="" class="img-fluid">
                    </div>
                    <div class="srv-2">
                        <p>
                            Superfast Delivery
                            <br>
                            Get your order delivered to your doorstep at the earliest from dark stores near you
                        </p>
                    </div>
                </div>
            </div>
            
            
        </div>
        
    </div>
    

    <?php include 'footer.php'; ?>
    <script>
        let basePrice = <?= htmlspecialchars($product['price']); ?>; // Base price of the product
        let quantity = 1; // Initial quantity

        function change_image(image_url) {
            document.querySelector("#get_src").src = image_url;
        }

        function changeQuantity(change) {
            quantity += change;
            if (quantity < 1) quantity = 1; // Prevents going below 1

            document.getElementById('quantity').value = quantity;
            document.getElementById('updatedPrice').innerText = (basePrice * quantity).toFixed(2);
        }
    </script>


    <script>
        function change_image(image_url) {
            document.querySelector("#get_src").src = image_url;
        }
    </script>

</body>
</html>
