<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            width: 100%;
            height: 100%;
            background-image: url("screenshot.jpg");
            background: transparent;
        }

        .box {
            width: 550px;
            height: 350px;
            background-color: white;
            /* align-items: center; */
            margin-left: 450px;
            margin-top: 135px;
            border-radius: 20px;
            text-align: center;
            row-gap: 3rem;
            border:  1px solid rgb(160, 159, 159);

        }

        .text {
            margin-bottom: 30px;
        }
        .image img{
            margin-top: 23px;
        }
        .btn button{
            width: 260px;
            height: 47px;
            border-radius: 10px;
            gap: 2px;
            background-color: white;
            color: black;
            border: 1px solid rgb(205, 201, 201);
        }
        .btn1 button{
            width: 260px;
            height: 47px;
            border-radius: 10px;
            gap: 2px;
            background-color: #b3b2b2;
            border: 1px solid rgb(205, 201, 201);
            color: white;

        }
        .btn b{
            margin-right: 204px;
        }
    </style>




</head>

<body>
    <div class="box">
        <div class="image">
            <img src="https://cdn.grofers.com/layout-engine/2023-11/app_logo.svg" alt="">
        </div>
        <div class="text">

            <h1>India's last minute app</h1>
            <p>Log in or Sign up</p>
        </div>
        <div class="btn">
            <button><b>+91</b></button> 
        </div>
        <br>
        <div class="btn1">
            <button><b>continue</b></button>
        </div>
        

    </div>
</body>

</html>