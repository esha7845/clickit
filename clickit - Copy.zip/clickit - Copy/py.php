<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include "config.php";

$user_id = $_SESSION['user_id'];

// Fetch user data
$user_query = $db->query("SELECT * FROM user WHERE u_id = $user_id");
$user = $user_query->fetch_assoc();

// Fetch cart data
$cart_query = $db->query("
  SELECT c.*, p.p_name AS product_name, p.image 
  FROM cart c 
  JOIN product p ON c.product_id = p.p_id 
  WHERE c.user_id = $user_id
");

if (!$cart_query) {
    die('Cart Query Error: ' . $db->error);
}

$cart_items = $cart_query->fetch_all(MYSQLI_ASSOC);


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      overflow-x: hidden;
    }

    .btn-group {
      height: 70px;
    }

    .btn-group button {
      width: 663px;
      text-align: left;
      border-bottom: 1px solid rgb(230, 230, 230);
    }

    .box {
      border: 1px solid rgb(230, 230, 230);
      border-radius: 10px;
      margin-top: 30px;

    }

    .box h5 {
      margin-left: 10px;
    }

    .box-1 {
      border: 1px solid rgb(230, 230, 230);

    }

    .box-1 h5 {
      margin-top: 14px;
      margin-left: 18px;
    }

    .del-add {
      border-bottom: 1px solid rgb(230, 230, 230);
    }

    .del-add {
      color: rgb(99, 98, 98);

    }

    .del-cart {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgb(230, 230, 230);


    }

    .del-cart p {
      margin-top: 10px;
      margin-right: 15px;
    }

    .del-cart h5 {
      margin-top: 0px;
      color: rgb(99, 98, 98);

    }

    .del-prdt {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-right: 86px;
      margin-left: 15px;
    }

    .del-prdt img {
      width: 60px;
      height: 50px;
    }

    .box-1 button {
      width: 283px;
      height: 45px;
      border-radius: 10px;
      background-color: rgb(210, 208, 208);
      color: white;
      border: 1px solid rgb(230, 230, 230);
      margin-left: 18px;
      margin-top: 20px;
    }

    .modal-content {
      border-radius: 15px;
    }

    /* .map {
      height: 300px;
      background-color: #cfcfcf;
      
    } */

    .btn span {
      color: #138624;
    }

    /* .brd{
      border: 1px solid rgb(230, 230, 230);
    } */
    .bu button {
      background-color: #138624;
      color: white;
    }

    #map {
      height: 300px;
      /* Set the height of the map */
      width: 100%;
      /* Set the width of the map */
    }

    .modal-body {
      display: flex;
      flex-direction: column;
    }

    .form-group {
      margin-bottom: 1rem;
    }
  </style>
</head>

<body>
  <div class="row" style="border-bottom: 1px solid rgb(230, 230, 230);">
    <div class="col-md-2 logo" style=" margin-right: -55px; margin-bottom: 11px;">
      <a class="active" href="index.php">
        <img src="https://www.thehealthfactory.in/cdn/shop/files/BLINKIT_876a5ffa-38b0-4f7b-8c54-0c3b56d69c38.png?crop=center&height=2048&v=1697781264&width=2048"
          alt="" class="img-fluid">
      </a>
    </div>
  </div>

  <div class="address">
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <div class="row">
          <div class="col-md-8">
            <div class="brd">
              <h3><b style="margin-left: -122px;">Select Delivery Address</b></h3>
              <div class="box">
                <div class="del-add mt-3">
                  <h5>Delivery Address</h5>
                  <?php if (!empty($user['address'])): ?>
                    <p>
                      <?= htmlspecialchars($user['name']) ?><br>
                      <?= nl2br(htmlspecialchars($user['address'])) ?><br>
                      <?= htmlspecialchars($user['city']) ?>, <?= htmlspecialchars($user['state']) ?> - <?= htmlspecialchars($user['pincode']) ?><br>
                      Phone: <?= htmlspecialchars($user['number']) ?>
                    </p>
                  <?php else: ?>
                    <p>No address found. <a href="#" data-toggle="modal" data-target="#addressModal">Add Address</a></p>
                  <?php endif; ?>
                </div>

                <h5>Delivery on this order</h5>
                <div class="container mt-2">
                  <button type="button" class="btn btn-light" style="color: #138624;" data-toggle="modal"
                    data-target="#addressModal">
                    +add new address
                  </button>
                </div>

                <div class="container mt-2">
                  <div class="accordion" id="paymentAccordion">
                    <div class="card">
                      <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                          <button class="btn" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                            aria-controls="collapseOne">
                            PAYMENT
                          </button>
                        </h2>
                      </div>

                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                        data-parent="#paymentAccordion">
                        <div class="card-body">
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" value="cod" id="cod">
                            <label class="form-check-label" for="cod">
                              Cash on delivery
                            </label>
                          </div>
                          <div class="form-check mt-2">
                            <input class="form-check-input" type="radio" name="payment_method" value="upi" id="upi">
                            <label class="form-check-label" for="upi">
                              UPI
                            </label>
                          </div>
                          <div class="form-check mt-2">
                            <input class="form-check-input" type="radio" name="payment_method" value="card" id="card">
                            <label class="form-check-label" for="card">
                              Card
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> <!-- container -->
              </div> <!-- box -->
            </div> <!-- brd -->
          </div>

          <div class="col-md-4">
            <div class="box-1">
              <div class="del-add">
                <h5>Delivery Address</h5>
                <?php if (!empty($user['address'])): ?>
                  <p>
                    <?= htmlspecialchars($user['name']) ?><br>
                    <?= nl2br(htmlspecialchars($user['address'])) ?><br>
                    <?= htmlspecialchars($user['city']) ?>, <?= htmlspecialchars($user['state']) ?> - <?= htmlspecialchars($user['pincode']) ?><br>
                    Phone: <?= htmlspecialchars($user['number']) ?>
                  </p>
                <?php else: ?>
                  <p>No address found. <a href="#" data-toggle="modal" data-target="#addressModal">Add Address</a></p>
                <?php endif; ?>
              </div>

              <div class="del-cart">
                <h5>My Cart</h5>
                <p><?= count($cart_items) ?> items</p>
              </div>

              <?php
              $total = 0;
              foreach ($cart_items as $item):
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
              ?>
              <div class="del-prdt">
                <img src="uploads/<?= htmlspecialchars($item['image']) ?>" alt="">
                <div class="te-xt">
                  <?= htmlspecialchars($item['product_name']) ?><br>
                  Qty: <?= $item['quantity'] ?> x ₹<?= $item['price'] ?><br>
                  <b>Total: ₹<?= $subtotal ?></b>
                </div>
              </div>
              <?php endforeach; ?>

              <div class="bu">
                <form action="confirm_payment.php" method="POST" onsubmit="return validatePayment();">
                  <input type="hidden" name="total" value="<?= $total ?>">
                  <input type="hidden" name="user_id" value="<?= $user_id ?>">
                  <button type="submit">Pay Now</button>
                </form>
              </div>

            </div>
          </div>
        </div>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>

  <!-- Address Modal -->
  <div class="modal fade" id="addressModal" tabindex="-1" role="dialog" aria-labelledby="addressModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addressModalLabel">Enter Complete Address</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- Google Maps or Map Link -->
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18..."
            width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          <small><a href="https://www.google.com/maps" target="_blank">Go to current location</a></small>

          <form class="mt-3" action="save_address.php" method="POST">
            <div class="form-group">
              <label for="addressType">Save address as:</label>
              <select class="form-control" name="type" id="addressType">
                <option>Home</option>
                <option>Work</option>
                <option>Hotel</option>
                <option>Other</option>
              </select>
            </div>
            <div class="form-group">
              <label>Flat / House no / Building name *</label>
              <input type="text" class="form-control" name="address" required>
            </div>
            <div class="form-group">
              <label>City *</label>
              <input type="text" class="form-control" name="city" required>
            </div>
            <div class="form-group">
              <label>State *</label>
              <input type="text" class="form-control" name="state" required>
            </div>
            <div class="form-group">
              <label>Pincode *</label>
              <input type="text" class="form-control" name="pincode" required>
            </div>
            <div class="form-group">
              <label>Phone *</label>
              <input type="text" class="form-control" name="number" required>
            </div>
            <input type="hidden" name="user_id" value="<?= $user_id ?>">
            <div class="modal-footer">
              <button type="submit" class="btn btn-success">Submit</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    function validatePayment() {
      const selected = document.querySelector('input[name="payment_method"]:checked');
      if (!selected) {
        alert("Please select a payment method.");
        return false;
      }
      return true;
    }
  </script>
</body>
</html>
