<?php 
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$user_sql = "SELECT * FROM user WHERE u_id = ?";
$user_stmt = $db->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch cart items (corrected JOIN with product using p_id)
$cart_sql = "SELECT p.p_name, p.price, p.image, c.quantity 
             FROM cart c 
             JOIN product p ON c.product_id = p.p_id 
             WHERE c.u_id = ?";
$cart_stmt = $db->prepare($cart_sql);
$cart_stmt->bind_param("i", $user_id);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

$subtotal = 0;
$items = [];
while ($row = $cart_result->fetch_assoc()) {
    $items[] = $row;
    $subtotal += $row['price'] * $row['quantity'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  
  

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
 
  <style>
    body {
      overflow-x: hidden;
    }

    .btn-group {
      height: 70px;
    }

    .btn-group button {
      width: 663px;
      text-align: left;
      border-bottom: 1px solid rgb(230, 230, 230);
    }

    .box {
      border: 1px solid rgb(230, 230, 230);
      border-radius: 10px;
      margin-top: 30px;

    }

    .box h5 {
      margin-left: 10px;
    }

    .box-1 {
      border: 1px solid rgb(230, 230, 230);

    }

    .box-1 h5 {
      margin-top: 14px;
      margin-left: 18px;
    }

    .del-add {
      border-bottom: 1px solid rgb(230, 230, 230);
    }

    .del-add {
      color: rgb(99, 98, 98);

    }

    .del-cart {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgb(230, 230, 230);


    }

    .del-cart p {
      margin-top: 10px;
      margin-right: 15px;
    }

    .del-cart h5 {
      margin-top: 0px;
      color: rgb(99, 98, 98);

    }

    .del-prdt {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-right: 86px;
      margin-left: 15px;
    }

    .del-prdt img {
      width: 60px;
      height: 50px;
    }

    .box-1 button {
      width: 283px;
      height: 45px;
      border-radius: 10px;
      background-color: rgb(210, 208, 208);
      color: white;
      border: 1px solid rgb(230, 230, 230);
      margin-left: 18px;
      margin-top: 20px;
    }

    .modal-content {
      border-radius: 15px;
    }

    /* .map {
      height: 300px;
      background-color: #cfcfcf;
      
    } */

    .btn span {
      color: #138624;
    }

    /* .brd{
      border: 1px solid rgb(230, 230, 230);
    } */
    .bu button {
      background-color: #138624;
      color: white;
    }

    #map {
      height: 300px;
      /* Set the height of the map */
      width: 100%;
      /* Set the width of the map */
    }

    .modal-body {
      display: flex;
      flex-direction: column;
    }

    .form-group {
      margin-bottom: 1rem;
    }
  </style>
</head>

<body>
  <div class="row" style="border-bottom: 1px solid rgb(230, 230, 230); ">


    <div class=" col-md-2 logo" style=" margin-right: -55px; margin-bottom: 11px;">
      <a class="active" href="index.html">
        <img
          src="https://www.thehealthfactory.in/cdn/shop/files/BLINKIT_876a5ffa-38b0-4f7b-8c54-0c3b56d69c38.png?crop=center&height=2048&v=1697781264&width=2048"
          alt="" class="img-fluid">
      </a>
    </div>

  </div>

  <div class="address">
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <div class="row">
          <div class="col-md-8">
            <div class="brd">
              <h3><b style="margin-left: -122px;">Select Delivery Address</b></h3>
              <div class="box">
                <div class="del-add mt-3">
                  <h5>Delivery Address</h5>
                  <p>Home: Floor 2, 1. Delhi Sarai Rohilla <br>Railway Station Guru Gobinda Singh Marg,<br> Railway
                    Officers Colony, Sarai Rohilla, <br>New delhi, delhi, india delhi</p>
                </div>
                <h5>Delivery on this order</h5>
                <div class="container mt-2">
                  <!-- Button to Open the Modal -->
                  <!-- Button to trigger modal -->
                  <button type="button" class="btn btn-light" style="color: #138624;" data-toggle="modal"
                    data-target="#addressModal">
                    +add new address
                  </button>




                </div>

                <div class="container mt-2">


                  <div class="accordion" id="paymentAccordion">
                    <div class="card">
                      <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                          <button class="btn" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                            aria-controls="collapseOne">
                            PAYMENT
                          </button>
                        </h2>
                      </div>

                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                        data-parent="#paymentAccordion">
                        <div class="card-body">
                          <div class="form-check ">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                            <label class="form-check-label" for="flexRadioDefault1">
                              Cash on delivery
                            </label>
                          </div>
                          <div class="form-check mt-2">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2"
                              checked>
                            <label class="form-check-label" for="flexRadioDefault2">
                              UPI
                            </label>
                          </div>
                          <div class="form-check mt-2">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2"
                              checked>
                            <label class="form-check-label" for="flexRadioDefault2">
                              Card
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>


                  </div>
                </div>
              </div>


            </div>
          </div>
          <div class="col-md-4">
            <div class="box-1">
            <div id="cart-items">
            <?php 
            while($cart_values = $cart_data1->fetch_object()) {
                $p_id = $cart_values->product_id;
                $p_data = $db->query("SELECT * FROM product WHERE p_id = '$p_id'");
                $p_value = $p_data->fetch_object();

                $subtotal += ($cart_values->price * $cart_values->quantity);
            ?>
            <div class="img-tx" id="cart-item-<?= $p_id ?>">
                <img src="uploads/<?= $p_value->image ?>" alt="">
                <div class="te-xt">
                    <?= $p_value->p_name ?> <br>
                    <?= $p_value->unit ?> <br>
                    <i class="fa-solid fa-indian-rupee-sign"></i> <span class="price"><?= $cart_values->price ?></span>
                </div>
                <div class="remv"> 
                    <button type="button" class="set-get" onclick="updateQuantity(<?= $p_id ?>, 'decrease')">-</button>
                    <span id="quantity-<?= $p_id ?>"><?= $cart_values->quantity ?></span>
                    <button type="button" class="set-get" onclick="updateQuantity(<?= $p_id ?>, 'increase')">+</button>
                    
                    <button type="button" class="remove-btn" onclick="removeItem(<?= $p_id ?>, <?= $cart_values->price ?>)">Remove</button>
                </div>
            </div>
            <?php } ?>
        </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>


  <!-- Modal Structure -->
  <div class="modal fade" id="addressModal" tabindex="-1" role="dialog" aria-labelledby="addressModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addressModalLabel">Enter Complete Address</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- Google Maps or Map Link -->
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345090903!2d144.95373531531672!3d-37.81720997975184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f12eb41%3A0x5045675218cee80!2sMelbourne%20Central!5e0!3m2!1sen!2sau!4v1616054443191!5m2!1sen!2sau"
            width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

          <small><a href="https://www.google.com/maps" target="_blank">Go to current location</a></small>

          <form class="mt-3" action="mng_checkout.php" method="POST">
            <div class="form-group">
              <label for="addressType">Save address as:</label>
              <select class="form-control" id="addressType" value="<?= htmlspecialchars($user['address'] ?? '') ?>">
                <option>Home</option>
                <option>Work</option>
                <option>Hotel</option>
                <option>Other</option>
              </select>
            </div>
            <div class="form-group">
              <label for="buildingName">Flat / House no / Building name *</label>
              <input type="text" class="form-control" id="buildingName" value="<?= htmlspecialchars($user['apartment'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label for="floor">Floor (optional)</label>
              <input type="text" class="form-control" id="floor">
            </div>
            <div class="form-group">
              <label for="locality">Area / Sector / Locality *</label>
              <input type="text" class="form-control" id="locality" value="<?= htmlspecialchars($user['area'] ?? '') ?>"  required>
            </div>
            <div class="form-group">
              <label for="city"> city</label>
              <input type="text" class="form-control" id="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>"  required>
            </div>
            <div class="form-group">
              <label for="state">state</label>
              <input type="text" class="form-control" id="state" value="<?= htmlspecialchars($user['state'] ?? '') ?>"  required>
            </div>
            <div class="form-group">
              <label for="pincode">pincode</label>
              <input type="text" class="form-control" id="pincode" value="<?= htmlspecialchars($user['pincode'] ?? '') ?>"  required>
            </div>
            <div class="form-group">
              <label for="name">Your name *</label>
              <input type="text" class="form-control" id="name" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>
            <div class="form-group">
              <label for="email">Your email *</label>
              <input type="text" class="form-control" id="email" value="<?= htmlspecialchars($user['email']) ?>" readonly>
            </div>
            <div class="form-group">
              <label for="phone">Your phone number (optional)</label>
              <input type="tel" class="form-control" id="phone" value="<?= htmlspecialchars($user['number']) ?>" >
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-success">Submit</button>
        </div>
      </div>
    </div>
  </div>




   

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script> -->
</body>

</html>