
<?php
session_start();

include "config.php"; // Database connection

?>


<!DOCTYPE html>
<html lang="en">

<head>
 

    <style>
        * {
            margin: 0px;
            padding: 0px;
        }



        /* .logo img {
            width: 145px;
            height: 43px;
            margin-left: 10px;
        } */

        .main-image img {
            width: 83%;
            height: 100%;
            margin-left: 140px;
        }

        .image1 {
            width: 70%;
            margin-left: 165px;
            display: flex;

        }

        .image1 img {
            width: 95%;

        }

        .im-2 {
            margin-left: 10px;
        }

        .im-3 {
            margin-left: 10px;
        }

        input {
            width: 200px;
            height: 45px;
            border-radius: 10px;
            /* border: 1px solid grey; */
            border: 1px solid rgb(188, 184, 184);
        }

        .text2 a {
            text-decoration: none;
            color: rgb(22, 21, 21);

        }

        .btn button {
            background-color: rgb(0, 118, 0);
            color: white;
            width: 100px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .col-md-1 img {
            width: 100px;
            height: 46px;
            padding-top: 12px;
            margin-bottom: 10px;
            margin: -12 7px;
        }

        .col-md-2 h6 {
            flex-direction: row;
        }

        .col-md-2 button {
            margin-left: 50px;
        }

        .col-md-1 {
            text-align: center;
            margin-top: 10px;
        }

        .row {
            width: 100%;
            height: 100%;
            display: flex;
            /* border-bottom: 1px solid rgb(230, 230, 230); */
            margin-top: 10px;

        }

        .image img {
            width: 83%;
            height: 100%;
            margin-left: 133px;
            margin-top: 10px;
        }

        .image-1 {
            width: 89%;
            margin-left: 165px;
            height: 100%;
            display: flex;


        }

        .image-2 {
            margin-top: 6px;
        }

        .image-1 img {
            width: 103%;

        }

        .image-2 img {
            width: 116px;
            height: 173px;
        }

        .image-3 {
            margin-top: -47px;
        }

        .image-3 img {
            width: 116px;
            height: 173px;
        }

        /* .mycontainer2 {
            max-width: 100%;
            overflow: auto hidden;
            scrollbar-width: none;
            display: flex;
            flex-direction: row;
            -webkit-box-align: center;
            align-items: center;
            padding-bottom: 20px;
            column-gap: 20px;
            margin-left: 30px;
            margin-right: 12px;


        } */

        .btn button {
            background-color: green;
            color: white;
            width: 80px;
            height: 45px;
            border-radius: 10px;
            text-align: center;
        }

        .col-md-4 {
            display: flex;
            /* gap: 5rem; */
            align-items: center;
        }

        .col-md-5 ul {
            list-style: none;
            margin-bottom: 105px;
        }

        a {
            text-decoration: none;
            color: #727272;
        }


        .col-md-7 {
            display: flex;
            gap: 3rem;
            align-items: center;
        }

        .col-md-7 ul {
            list-style: none;
        }

        .row {
            margin-top: 20px;
        }

        .col-md-4 {
            display: flex;
            gap: 2rem;
            align-items: center;
        }

        b {
            font-family: "Parkinsans", sans-serif;
            font-weight: 900px;
            font-size: 18px;
            /* font-family: "Kanit", sans-serif;
            font-family: "Kanit", sans-serif;
            font-weight: 900; */
        }

        .head {
            margin-top: 80px;
            margin-left: 42px;
            margin-bottom: 10px;
        }

        .mycontainer2 {
            /* width: 97%; */
            margin-left: 165px;
        }

        .download img {
            width: 254px;
        }

        /* .text {
            margin-bottom: 30px;
        } */
         .wrap{
            text-align: center;
            margin-top: 23px;
         }
    </style>
</head>
    <?php include 'header.php';?>
         
<body style="margin: 0; padding: 0; overflow-x: hidden;">


    <div class="image">
        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=2700/layout-engine/2022-05/Group-33704.jpg"
            class="img-fluid" alt="...">
    </div>

<div class="container">
    <div class="image-1" style="width: 115%;
    margin-left: 56px;" >
        <div class="row">

            <div class="col-md-3">
                <a href="Productonline.php"><img
                        src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-07/pharmacy-WEB.jpg"
                        class="img-fluid" alt="..."></a>
            </div>
            <div class="col-md-3">
                <a href="Productonline.php"><img
                        src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-07/Pet-Care_WEB.jpg"
                        class="img-fluid" alt="..."></a>
            </div>
            <div class="col-md-3">
                <a href="Productonline.php"><img
                        src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-03/babycare-WEB.jpg"
                        class="img-fluid" alt="..."></a>
            </div>
        </div>
    </div>
</div>

    <div class="container-fluid">
    <div class="image-2">
        <div class="row">
            <div class="col-md-1"></div>
            <?php
            $count = 0; // Counter to track images
            $data = $db->query("SELECT * FROM `category`");
            while ($value = $data->fetch_object()) {
                if ($count % 10 == 0 && $count != 0) {
                    echo '</div><div class="row"><div class="col-md-1"></div>'; // Close current row & start new row with left spacing
                }
            ?>
                <div class="col-md-1">
                    <a href="product.php?category_id=<?= $value->c_id; ?>">
                        <img src="<?= !empty($value->file) ? 'uploads/' . htmlspecialchars($value->file) : 'uploads/default.jpg'; ?>" 
                            class="img-fluid" alt="<?= htmlspecialchars($value->c_name); ?>">
                    </a>
                </div>
            <?php 
                $count++; // Increment image counter
            } 
            ?>
            <div class="col-md-1"></div>
        </div>
    </div>
</div>


<!-- Fetch Categories and Display Products in Slider -->
<?php
$query = "SELECT c.c_id, c.c_name, p.* 
          FROM category c
          LEFT JOIN product p ON c.c_id = p.c_id 
          ORDER BY c.c_id, p.p_id";

$result = $db->query($query);

$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[$row['c_id']]['c_name'] = $row['c_name'];
    if (!empty($row['p_id'])) { // Only add products if they exist    
        $categories[$row['c_id']]['products'][] = $row;
    }
}

// Loop through categories
foreach ($categories as $category) {
?>
    <div class="container-fluid">
        <h3 class="mt-3"><?= htmlspecialchars($category['c_name']); ?></h3>

        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
    <?php if (!empty($category['products'])) { ?>
        <div class="owl-carousel owl-theme">
            <?php foreach ($category['products'] as $product) { ?>
                <div class="item">
                    <div class="card item">
                        <div class="card-body">
                            <a href="productdetails.php?p_id=<?= urlencode($product['p_id']); ?>">
                                <img src="<?= !empty($product['image']) ? 'uploads/' . htmlspecialchars($product['image']) : 'uploads/default.jpg'; ?>" 
                                    alt="<?= htmlspecialchars($product['p_name']); ?>" class="img-fluid">
                            </a>
                        </div>
                        <div class="card-footer">
                            <h6>⏱ 8 MIN</h6>
                            <h6>
                                <a href="productdetails.php?p_id=<?= urlencode($product['p_id']); ?>" style="text-decoration: none; color: inherit;">
                                    <?= htmlspecialchars($product['p_name']); ?>
                                </a>
                            </h6>
                            <p><?= htmlspecialchars($product['unit']); ?></p>
                            <div class="pbtn">
                                <h6>₹<?= htmlspecialchars($product['price']); ?></h6>

                                <!-- Add to Cart Form -->
                             <form action="admin/action/add_to_cart.php" method="post">
    <input type="hidden" name="submit" value="add_to_cart">
    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['p_id']); ?>">
    <input type="hidden" name="u_id" value="<?= isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0; ?>">

    <input type="hidden" name="quantity" value="1">
    <button type="submit">ADD</button>
</form>

                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    <?php } else { ?>
        <p style="text-align: center; font-weight: bold;">No product under this category available</p>
    <?php } ?>
</div>


            <div class="col-md-1"></div>
        </div>
    </div>
<?php
}
?>

<?php


if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']); // Get product ID safely

    // Remove the item from the cart table
    $stmt = $db->prepare("DELETE FROM cart WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);

    if ($stmt->execute()) {
        // Redirect back to index.php without ID in the URL
        header("Location: index.php");
        exit();
    } else {
        echo "Error removing item.";
    }
}
?>



    
    
    
    <?php include 'footer.php'; ?>
    













    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
        integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script> -->



    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            dots: false,
            autoplay: true,
            autoplayTimeout: 5000,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 6
                }
            }
        })
    </script>
</body>

</html>